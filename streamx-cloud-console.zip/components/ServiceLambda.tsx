
import React, { useState } from 'react';
import { INITIAL_LAMBDA_FUNCTIONS } from '../constants';
import { Search, Plus, Trash2, RefreshCw, Zap, Code, Settings, X, ChevronRight, Activity } from 'lucide-react';
import { LambdaFunction } from '../types';
import { useNotifications } from '../App';

export const ServiceLambda: React.FC = () => {
  const { addNotification } = useNotifications();
  const [functions, setFunctions] = useState<LambdaFunction[]>(INITIAL_LAMBDA_FUNCTIONS);
  const [search, setSearch] = useState('');
  const [selectedFn, setSelectedFn] = useState<string | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newFnName, setNewFnName] = useState('');
  const [newFnRuntime, setNewFnRuntime] = useState('Node.js 20.x');

  const filteredFns = functions.filter(fn => 
    fn.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleCreateFunction = () => {
    if (!newFnName) return;
    const cleanName = newFnName.replace(/\s+/g, '-').toLowerCase();
    const now = new Date().toLocaleString();
    const newFn: LambdaFunction = {
      name: cleanName,
      runtime: newFnRuntime,
      description: 'Newly created serverless function',
      lastModified: now,
      memory: 128
    };
    setFunctions([newFn, ...functions]);
    setIsCreateModalOpen(false);
    setNewFnName('');
    addNotification('Lambda', `Serverless function "${cleanName}" deployed at ${now}.`, "success");
  };

  const handleDelete = () => {
    if (selectedFn) {
      setFunctions(functions.filter(f => f.name !== selectedFn));
      addNotification('Lambda', `Function "${selectedFn}" has been deleted.`, "warning");
      setSelectedFn(null);
    }
  };

  const currentFnData = functions.find(f => f.name === selectedFn);

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center bg-white sticky top-0 z-20">
        <div>
          <h1 className="text-2xl font-bold text-[#161e2d]">Functions</h1>
          <p className="text-sm text-gray-500">Lambda > Functions</p>
        </div>
        <div className="flex space-x-3">
          <button 
            disabled={!selectedFn}
            onClick={handleDelete}
            className="px-4 py-1.5 border border-red-200 text-red-600 rounded text-sm font-bold hover:bg-red-50 disabled:opacity-50"
          >
            Delete
          </button>
          <button 
            onClick={() => setIsCreateModalOpen(true)}
            className="px-4 py-1.5 bg-[#ec7211] text-white rounded text-sm font-bold hover:bg-[#d66100] shadow-sm flex items-center"
          >
            <Plus size={16} className="mr-1" /> Create function
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col">
        <div className="bg-white p-4 border-b border-gray-200 flex items-center space-x-4">
          <div className="relative flex-1 max-w-xl">
            <Search className="absolute left-3 top-2.5 text-gray-400" size={16} />
            <input 
              type="text" 
              placeholder="Search functions" 
              className="w-full pl-9 pr-4 py-1.5 border border-gray-300 rounded text-sm focus:ring-1 focus:ring-[#ec7211] outline-none"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <button onClick={() => { setFunctions(INITIAL_LAMBDA_FUNCTIONS); addNotification('Lambda', "Lambda registry refreshed.", "info"); }} className="p-2 text-gray-600 hover:bg-gray-100 rounded border border-gray-300">
            <RefreshCw size={18} />
          </button>
        </div>

        <div className="p-4 overflow-auto bg-[#f8f9fa] flex-1">
          <div className="border border-gray-300 rounded overflow-hidden bg-white shadow-sm">
            <table className="w-full text-left text-sm">
              <thead className="bg-gray-50 border-b border-gray-200 text-gray-600 uppercase text-[10px] font-bold">
                <tr>
                  <th className="p-3 w-10"></th>
                  <th className="p-3">Function name</th>
                  <th className="p-3">Runtime</th>
                  <th className="p-3">Description</th>
                  <th className="p-3">Last modified</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredFns.map((fn) => (
                  <tr 
                    key={fn.name} 
                    className={`hover:bg-blue-50 cursor-pointer ${selectedFn === fn.name ? 'bg-blue-50' : ''}`}
                    onClick={() => setSelectedFn(fn.name)}
                  >
                    <td className="p-3 text-center">
                      <input type="radio" checked={selectedFn === fn.name} readOnly />
                    </td>
                    <td className="p-3 font-bold text-[#0073bb] hover:underline flex items-center">
                      <Zap size={14} className="mr-2 text-yellow-500" />
                      {fn.name}
                    </td>
                    <td className="p-3 text-gray-600">{fn.runtime}</td>
                    <td className="p-3 text-xs text-gray-500 max-w-xs truncate">{fn.description}</td>
                    <td className="p-3 text-gray-500 font-mono text-[10px]">{fn.lastModified}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {selectedFn && currentFnData && (
          <div className="h-64 border-t border-gray-300 bg-white p-6 flex flex-col animate-in slide-in-from-bottom duration-300">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-800 flex items-center">
                <Settings size={18} className="mr-2 text-gray-400" />
                Function: {currentFnData.name}
              </h3>
              <div className="flex items-center space-x-2 text-xs text-green-600 bg-green-50 px-3 py-1 rounded-full border border-green-100">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                <span>Active & Healthy</span>
              </div>
            </div>
            
            <div className="grid grid-cols-4 gap-6">
              <div className="p-4 bg-gray-50 border rounded">
                <p className="text-[10px] uppercase font-bold text-gray-500 mb-1">Runtime</p>
                <p className="text-sm font-bold">{currentFnData.runtime}</p>
              </div>
              <div className="p-4 bg-gray-50 border rounded">
                <p className="text-[10px] uppercase font-bold text-gray-500 mb-1">Memory</p>
                <p className="text-sm font-bold">{currentFnData.memory} MB</p>
              </div>
              <div className="p-4 bg-gray-50 border rounded">
                <p className="text-[10px] uppercase font-bold text-gray-500 mb-1">Timeout</p>
                <p className="text-sm font-bold">3.0 seconds</p>
              </div>
              <div className="p-4 bg-gray-50 border rounded">
                <p className="text-[10px] uppercase font-bold text-gray-500 mb-1">Last Invocation</p>
                <div className="flex items-center space-x-1 text-green-600">
                  <Activity size={12} />
                  <p className="text-sm font-bold italic">Success (2ms ago)</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {isCreateModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[110] px-4">
          <div className="bg-white rounded shadow-2xl w-full max-w-xl overflow-hidden border border-gray-300">
            <div className="bg-gray-50 p-4 border-b border-gray-200 flex justify-between items-center">
              <h2 className="text-lg font-bold">Create function</h2>
              <button onClick={() => setIsCreateModalOpen(false)}><X size={20} /></button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Function name</label>
                <input 
                  type="text" 
                  className="w-full px-3 py-2 border rounded text-sm focus:ring-1 focus:ring-[#ec7211] outline-none" 
                  placeholder="e.g. my-awesome-function"
                  value={newFnName}
                  onChange={(e) => setNewFnName(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Runtime</label>
                <select 
                  className="w-full px-3 py-2 border rounded text-sm focus:ring-1 focus:ring-[#ec7211] outline-none bg-white"
                  value={newFnRuntime}
                  onChange={(e) => setNewFnRuntime(e.target.value)}
                >
                  <option>Node.js 20.x</option>
                  <option>Node.js 18.x</option>
                  <option>Python 3.11</option>
                  <option>Python 3.10</option>
                  <option>Ruby 3.2</option>
                  <option>Java 17</option>
                </select>
              </div>
              <div className="bg-orange-50 border-l-4 border-[#ec7211] p-4 flex items-start space-x-3">
                <Zap size={20} className="text-[#ec7211] mt-0.5" />
                <div className="text-xs text-orange-900 leading-relaxed">
                  <p className="font-bold">Author from scratch</p>
                  <p>Create a simple Hello World example. You can add triggers and code once the function is created.</p>
                </div>
              </div>
            </div>
            <div className="bg-gray-50 px-6 py-4 border-t border-gray-200 flex justify-end space-x-3">
              <button onClick={() => setIsCreateModalOpen(false)} className="px-6 py-2 text-sm font-bold text-gray-700 border border-gray-300 bg-white rounded">Cancel</button>
              <button onClick={handleCreateFunction} className="px-6 py-2 text-sm font-bold bg-[#ec7211] text-white rounded shadow hover:bg-[#d66100]">Create Function</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
