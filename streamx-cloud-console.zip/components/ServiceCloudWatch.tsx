
import React, { useState, useEffect, useRef } from 'react';
import { Terminal, Search, Pause, Play, Download, Trash2, Filter, AlertCircle, Clock } from 'lucide-react';

const LOG_MESSAGES = [
  "INFO: Transcoder cluster-A scaling up. 4 new nodes added.",
  "DEBUG: HLS Manifest requested for stream-id-v882.",
  "WARN: High latency detected from Mumbai Edge-02.",
  "INFO: S3 Segment upload successful: segment_0441.ts",
  "ERROR: Database connection timeout (RDS primary). Retrying...",
  "INFO: User 9921 authenticated via API Gateway.",
  "DEBUG: CDN Cache hit ratio at 98.4%",
  "INFO: Global Shield blocked IP 45.xx.xx.xx (Malicious headers)",
];

export const ServiceCloudWatch: React.FC = () => {
  const [logs, setLogs] = useState<string[]>([]);
  const [isPaused, setIsPaused] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isPaused) return;
    const interval = setInterval(() => {
      const msg = LOG_MESSAGES[Math.floor(Math.random() * LOG_MESSAGES.length)];
      const timestamp = new Date().toLocaleTimeString();
      setLogs(prev => [...prev.slice(-49), `[${timestamp}] ${msg}`]);
    }, 1500);
    return () => clearInterval(interval);
  }, [isPaused]);

  useEffect(() => {
    if (scrollRef.current && !isPaused) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <div className="flex flex-col h-full bg-[#0d1117] text-gray-300 font-mono text-xs">
      <div className="bg-[#1b2531] p-4 border-b border-white/5 flex items-center justify-between font-sans">
         <div className="flex items-center space-x-3">
            <Terminal className="text-green-500" size={18} />
            <h1 className="font-bold text-white">CloudWatch Logs - Production</h1>
         </div>
         <div className="flex items-center space-x-4">
            <div className="relative">
               <Search className="absolute left-2 top-1.5 text-gray-500" size={14} />
               <input type="text" placeholder="Filter logs..." className="bg-black/50 border border-white/10 rounded px-8 py-1 focus:outline-none focus:border-blue-500" />
            </div>
            <button onClick={() => setIsPaused(!isPaused)} className="text-gray-400 hover:text-white">
               {isPaused ? <Play size={16} /> : <Pause size={16} />}
            </button>
            <button onClick={() => setLogs([])} className="text-gray-400 hover:text-red-400">
               <Trash2 size={16} />
            </button>
         </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-1 custom-scrollbar scroll-smooth">
         {logs.map((log, i) => (
            <div key={i} className={`flex space-x-3 ${log.includes('ERROR') ? 'text-red-400 bg-red-400/5' : log.includes('WARN') ? 'text-yellow-400' : ''}`}>
               <span className="opacity-40 whitespace-nowrap">{i + 1}</span>
               <span className="whitespace-pre-wrap">{log}</span>
            </div>
         ))}
         {logs.length === 0 && <p className="text-gray-600 italic">Waiting for incoming log stream...</p>}
      </div>

      <div className="bg-[#1b2531] p-2 px-4 border-t border-white/5 flex items-center justify-between text-[10px] font-sans text-gray-500">
         <div className="flex items-center space-x-4">
            <span className="flex items-center"><Clock size={10} className="mr-1"/> Log Stream: web-app-production-main</span>
            <span className="flex items-center"><AlertCircle size={10} className="mr-1"/> 2 Alerts suppressed by threshold</span>
         </div>
         <span>UTF-8 • Region: global-core-1</span>
      </div>
    </div>
  );
};
