
import React, { useState, useEffect } from 'react';
import { ShieldX, ShieldAlert, Globe, Activity, Lock, AlertTriangle, RefreshCw, Filter, ListFilter } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import { useNotifications } from '../App';

const MOCK_ATTACK_DATA = Array.from({ length: 12 }, (_, i) => ({
  hour: `${i}:00`,
  blocked: 50 + Math.floor(Math.random() * 200),
  allowed: 1000 + Math.floor(Math.random() * 500)
}));

export const ServiceWAF: React.FC = () => {
  const { addNotification } = useNotifications();
  const [data, setData] = useState(MOCK_ATTACK_DATA);
  const [isDDoSMode, setIsDDoSMode] = useState(false);

  const toggleDDoSMode = () => {
    setIsDDoSMode(!isDDoSMode);
    addNotification('WAF Shield', isDDoSMode ? 'Under-attack mode DISABLED.' : 'CRITICAL: Under-attack mode ENABLED. Captcha enforced globally.', isDDoSMode ? 'info' : 'warning');
  };

  return (
    <div className="flex flex-col h-full bg-[#f8f9fa] overflow-y-auto custom-scrollbar">
      <div className="bg-white p-6 border-b border-gray-200 flex justify-between items-center">
        <div>
           <h1 className="text-2xl font-bold text-[#161e2d] flex items-center">
              <ShieldX className="mr-2 text-orange-600" /> Web Application Firewall (WAF)
           </h1>
           <p className="text-sm text-gray-500">Protection for stream-lb-7712.streamx.com</p>
        </div>
        <button 
           onClick={toggleDDoSMode}
           className={`px-6 py-2 rounded font-bold text-sm shadow-md transition-all ${isDDoSMode ? 'bg-red-600 text-white animate-pulse' : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'}`}
        >
           {isDDoSMode ? 'Disable Under-Attack Mode' : 'Enable Under-Attack Mode'}
        </button>
      </div>

      <div className="p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
           <div className="bg-white p-6 border rounded shadow-sm border-l-4 border-l-orange-500">
              <div className="flex justify-between items-center mb-2">
                 <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Bot Mitigation</p>
                 <ShieldAlert size={16} className="text-orange-500" />
              </div>
              <p className="text-3xl font-black text-gray-800">2,412</p>
              <p className="text-[10px] text-gray-400 mt-1">Bots blocked in last 24h</p>
           </div>
           <div className="bg-white p-6 border rounded shadow-sm">
              <div className="flex justify-between items-center mb-2">
                 <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Top Threat Origin</p>
                 <Globe size={16} className="text-blue-500" />
              </div>
              <p className="text-3xl font-black text-gray-800">RU / CN</p>
              <p className="text-[10px] text-gray-400 mt-1">Region-based IP filtering active</p>
           </div>
           <div className="bg-white p-6 border rounded shadow-sm">
              <div className="flex justify-between items-center mb-2">
                 <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Active ACL Rules</p>
                 <ListFilter size={16} className="text-green-500" />
              </div>
              <p className="text-3xl font-black text-gray-800">42</p>
              <p className="text-[10px] text-gray-400 mt-1">Managed Rule Groups applied</p>
           </div>
        </div>

        <div className="bg-white border rounded shadow-sm p-6">
           <h3 className="text-sm font-bold text-gray-700 mb-6 flex items-center">
              <Activity size={16} className="mr-2 text-orange-500" /> Blocked Requests vs Traffic
           </h3>
           <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                 <BarChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                    <XAxis dataKey="hour" axisLine={false} tickLine={false} fontSize={10} />
                    <YAxis axisLine={false} tickLine={false} fontSize={10} />
                    <Tooltip />
                    <Bar dataKey="blocked" fill="#f97316" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="allowed" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                 </BarChart>
              </ResponsiveContainer>
           </div>
        </div>

        <div className="bg-[#161e2d] text-white p-6 rounded-lg border border-white/5">
           <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold flex items-center"><Lock size={14} className="mr-2 text-orange-400"/> Live Threat Log</h3>
              <button className="text-[10px] font-bold text-gray-500 hover:text-white flex items-center"><RefreshCw size={10} className="mr-1"/> Refresh</button>
           </div>
           <div className="space-y-3 font-mono text-[10px]">
              <div className="flex justify-between border-b border-white/5 pb-2">
                 <span className="text-red-400">[BLOCK] 45.122.1.92</span>
                 <span className="text-gray-500 text-right">SQL Injection Attempt on /user/auth</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-2">
                 <span className="text-red-400">[BLOCK] 103.4.92.11</span>
                 <span className="text-gray-500 text-right">Cross-Site Scripting (XSS) on /videos/list</span>
              </div>
              <div className="flex justify-between border-b border-white/5 pb-2">
                 <span className="text-yellow-400">[CHALLENGE] 192.168.0.1</span>
                 <span className="text-gray-500 text-right">Rate Limit Threshold Exceeded (Bot Detection)</span>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};
