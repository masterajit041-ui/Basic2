
import React from 'react';
import { HelpCircle, Book, MessageSquare, Phone, Search, ExternalLink, Shield, FileText, ChevronRight } from 'lucide-react';

export const ServiceSupport: React.FC = () => {
  return (
    <div className="flex flex-col h-full bg-[#f2f3f3] overflow-y-auto">
      {/* Header with Search */}
      <div className="bg-[#232f3e] text-white px-12 py-16 flex flex-col items-center">
        <h1 className="text-3xl font-bold mb-8">How can we help you?</h1>
        <div className="w-full max-w-2xl relative">
          <Search className="absolute left-4 top-3 text-gray-400" size={20} />
          <input 
            type="text" 
            placeholder="Search documentation, tutorials, and whitepapers" 
            className="w-full pl-12 pr-4 py-3 rounded bg-white text-gray-800 outline-none focus:ring-2 focus:ring-[#ec7211]"
          />
        </div>
      </div>

      <div className="p-12 max-w-7xl mx-auto w-full -mt-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[
            { icon: Book, title: 'Documentation', desc: 'Step-by-step guides for every service.' },
            { icon: MessageSquare, title: 'Knowledge Center', desc: 'Articles for common technical tasks.' },
            { icon: Shield, title: 'Security & Compliance', desc: 'StreamX security best practices.' },
            { icon: Phone, title: 'Contact Support', desc: 'Open a case with our support engineers.' },
          ].map((item, idx) => (
            <div key={idx} className="bg-white p-6 rounded shadow-sm border hover:shadow-md transition-shadow cursor-pointer flex flex-col items-center text-center">
              <div className="p-3 bg-gray-50 text-[#ec7211] rounded-full mb-4">
                <item.icon size={24} />
              </div>
              <h3 className="font-bold text-sm mb-2">{item.title}</h3>
              <p className="text-xs text-gray-500">{item.desc}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-12">
          {/* Active Cases */}
          <div className="bg-white border rounded shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b flex justify-between items-center">
              <h3 className="font-bold text-lg">Your support cases</h3>
              <button className="text-xs font-bold text-[#0073bb] hover:underline">View all</button>
            </div>
            <div className="p-12 flex flex-col items-center justify-center text-gray-400">
              <FileText size={48} className="mb-4 opacity-20" />
              <p className="text-sm font-medium">You have no active support cases.</p>
              <button className="mt-4 px-6 py-2 bg-[#ec7211] text-white rounded text-sm font-bold shadow-sm">
                Create case
              </button>
            </div>
          </div>

          {/* Featured Content */}
          <div className="bg-white border rounded shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b">
              <h3 className="font-bold text-lg">Featured content</h3>
            </div>
            <div className="divide-y">
              {[
                'StreamX Well-Architected Framework',
                'Getting Started with Serverless on StreamX',
                'Optimizing your RDS Database Performance',
                'Securing your S3 Buckets: A Checklist'
              ].map((text, idx) => (
                <div key={idx} className="p-4 flex justify-between items-center hover:bg-gray-50 cursor-pointer group">
                  <span className="text-sm font-medium text-gray-700 group-hover:text-[#0073bb]">{text}</span>
                  <ExternalLink size={14} className="text-gray-300" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
