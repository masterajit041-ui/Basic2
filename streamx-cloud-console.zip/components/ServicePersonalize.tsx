
import React, { useState } from 'react';
import { BrainCircuit, Activity, Database, Zap, Settings, Play, Target, LineChart as ChartIcon, Sparkles, RefreshCw } from 'lucide-react';
import { useNotifications } from '../App';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';

const MOCK_TRAINING_DATA = Array.from({ length: 12 }, (_, i) => ({
  time: `${i*2}h`,
  accuracy: 0.85 + (Math.random() * 0.1),
  loss: 0.1 - (Math.random() * 0.05)
}));

export const ServicePersonalize: React.FC = () => {
  const { addNotification } = useNotifications();
  const [isTraining, setIsTraining] = useState(false);

  const startTraining = () => {
    setIsTraining(true);
    addNotification('AI Personalize', 'Initiating ML model re-training with new click-stream data...', 'info');
    setTimeout(() => {
      setIsTraining(false);
      addNotification('AI Personalize', 'Personalization Campaign "User-Home-v2" updated. Performance increased by 4.2%.', 'success');
    }, 5000);
  };

  return (
    <div className="flex flex-col h-full bg-[#f8f9fa] overflow-y-auto custom-scrollbar">
      <div className="p-8 bg-gradient-to-r from-[#2c1e4d] to-[#4d2c7a] text-white">
        <div className="flex justify-between items-center">
           <div>
              <div className="flex items-center space-x-2 text-purple-400 mb-2">
                 <BrainCircuit size={20} className="animate-pulse" />
                 <span className="text-xs font-bold uppercase tracking-widest">Cognitive Intelligence Active</span>
              </div>
              <h1 className="text-3xl font-extrabold tracking-tight">AI Personalization</h1>
              <p className="text-gray-300 mt-2 max-w-lg text-sm italic">"The right content, for the right user, at the right time."</p>
           </div>
           <button onClick={startTraining} disabled={isTraining} className="bg-white text-[#2c1e4d] px-8 py-3 rounded-full font-bold text-sm shadow-xl flex items-center space-x-2 transition-all hover:scale-105 disabled:opacity-50">
              {/* Added RefreshCw to imports above to fix find name error */}
              {isTraining ? <RefreshCw className="animate-spin" size={18} /> : <Sparkles size={18} />}
              <span>{isTraining ? 'Training Model...' : 'Train Recommendations'}</span>
           </button>
        </div>
      </div>

      <div className="p-8 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
           <div className="bg-white p-6 border rounded-xl shadow-sm border-b-4 border-b-purple-500">
              <div className="flex justify-between items-center mb-4">
                 <h3 className="text-xs font-bold text-gray-500 uppercase">Click-Through Rate (Avg)</h3>
                 <Target size={16} className="text-purple-500" />
              </div>
              <p className="text-3xl font-black">12.4%</p>
              <p className="text-[10px] text-green-600 font-bold mt-1">+1.2% since last epoch</p>
           </div>
           <div className="bg-white p-6 border rounded-xl shadow-sm">
              <div className="flex justify-between items-center mb-4">
                 <h3 className="text-xs font-bold text-gray-500 uppercase">Active Campaigns</h3>
                 <Zap size={16} className="text-yellow-500" />
              </div>
              <p className="text-3xl font-black">8</p>
              <p className="text-[10px] text-gray-400 mt-1">A/B testing enabled</p>
           </div>
           <div className="bg-white p-6 border rounded-xl shadow-sm">
              <div className="flex justify-between items-center mb-4">
                 <h3 className="text-xs font-bold text-gray-500 uppercase">Inference Latency</h3>
                 <Activity size={16} className="text-blue-500" />
              </div>
              <p className="text-3xl font-black">42ms</p>
              <p className="text-[10px] text-gray-400 mt-1">Global edge optimized</p>
           </div>
           <div onClick={() => addNotification('Dataset', 'Importing user metadata...', 'info')} className="bg-purple-600 p-6 rounded-xl shadow-lg text-white cursor-pointer hover:bg-purple-700 transition-colors">
              <Database size={32} className="mb-4 opacity-50" />
              <p className="font-bold">Sync Data</p>
              <p className="text-[10px] opacity-70">Import new user events from S3</p>
           </div>
        </div>

        <div className="bg-white p-8 border rounded-xl shadow-sm h-80">
           <div className="flex items-center justify-between mb-8">
              <h3 className="text-sm font-bold text-gray-700 flex items-center space-x-2">
                 <ChartIcon size={16} className="text-purple-500" />
                 <span>Model Performance Matrix</span>
              </h3>
              <div className="flex items-center space-x-4">
                 <div className="flex items-center space-x-2"><div className="w-3 h-3 bg-purple-500 rounded-full" /><span className="text-[10px] text-gray-500">Accuracy</span></div>
                 <div className="flex items-center space-x-2"><div className="w-3 h-3 bg-red-400 rounded-full" /><span className="text-[10px] text-gray-500">Loss</span></div>
              </div>
           </div>
           <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                 <AreaChart data={MOCK_TRAINING_DATA}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                    <XAxis dataKey="time" hide />
                    <YAxis domain={[0, 1]} hide />
                    <Tooltip />
                    <Area type="monotone" dataKey="accuracy" stroke="#a855f7" fill="#a855f7" fillOpacity={0.1} strokeWidth={3} />
                    <Area type="monotone" dataKey="loss" stroke="#f87171" fill="#f87171" fillOpacity={0.05} strokeWidth={2} />
                 </AreaChart>
              </ResponsiveContainer>
           </div>
        </div>
      </div>
    </div>
  );
};
