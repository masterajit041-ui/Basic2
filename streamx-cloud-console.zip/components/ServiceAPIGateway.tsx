
import React, { useState } from 'react';
import { DoorOpen, Search, Plus, Zap, Shield, Key, RefreshCw, ChevronRight, Activity, Terminal } from 'lucide-react';
import { useNotifications } from '../App';

export const ServiceAPIGateway: React.FC = () => {
  const { addNotification } = useNotifications();
  const [endpoints, setEndpoints] = useState([
    { method: 'GET', path: '/videos/list', type: 'REST', status: 'Active' },
    { method: 'POST', path: '/user/auth', type: 'HTTP', status: 'Active' },
    { method: 'GET', path: '/stream/hls/manifest', type: 'WebSocket', status: 'Active' }
  ]);

  const handleDeploy = () => {
    addNotification('API GW', 'Deploying API Stage "Production" to all regions...', 'info');
    setTimeout(() => {
      addNotification('API GW', 'Deployment successful. Endpoint version v2.1.0 live.', 'success');
    }, 2000);
  };

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="p-6 border-b border-gray-200 flex justify-between items-center">
        <div>
           <h1 className="text-2xl font-bold text-[#161e2d] flex items-center">
              <DoorOpen className="mr-2 text-yellow-500" /> API Gateway
           </h1>
           <p className="text-sm text-gray-500">Managed API Endpoints & Throttling</p>
        </div>
        <button onClick={handleDeploy} className="bg-orange-600 text-white px-6 py-2 rounded font-bold text-sm shadow-md hover:bg-orange-700">Deploy API</button>
      </div>

      <div className="flex-1 p-8 grid grid-cols-1 lg:grid-cols-3 gap-8 overflow-y-auto">
        <div className="lg:col-span-2 space-y-6">
           <div className="border border-gray-200 rounded-lg overflow-hidden shadow-sm">
              <div className="bg-gray-50 px-4 py-2 border-b font-bold text-xs text-gray-500 uppercase">Resources & Methods</div>
              <div className="divide-y">
                 {endpoints.map((ep, i) => (
                    <div key={i} className="p-4 hover:bg-gray-50 flex items-center justify-between cursor-pointer group">
                       <div className="flex items-center space-x-4">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-black w-14 text-center ${
                             ep.method === 'GET' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
                          }`}>{ep.method}</span>
                          <span className="text-sm font-mono text-gray-700">{ep.path}</span>
                       </div>
                       <div className="flex items-center space-x-4">
                          <span className="text-[10px] font-bold text-gray-400">{ep.type}</span>
                          <ChevronRight size={14} className="text-gray-300 group-hover:text-orange-500" />
                       </div>
                    </div>
                 ))}
                 <button className="w-full p-4 text-xs font-bold text-[#0073bb] hover:underline flex items-center justify-center space-x-2">
                    <Plus size={14} /><span>Create Resource</span>
                 </button>
              </div>
           </div>

           <div className="bg-gray-900 text-green-400 p-6 rounded shadow-inner font-mono text-xs">
              <p className="text-gray-500 mb-2"># Access Logs (Simulated Streaming Auth Requests)</p>
              <p>[INFO] 2025-05-12 10:24:01 - POST /user/auth - 200 OK - 42ms</p>
              <p>[INFO] 2025-05-12 10:24:05 - GET /videos/list - 200 OK - 15ms</p>
              <p className="text-red-400">[WARN] 2025-05-12 10:24:08 - GET /admin/config - 403 FORBIDDEN - 5ms</p>
           </div>
        </div>

        <div className="space-y-6">
           <div className="bg-white border rounded-lg p-6 shadow-sm">
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4 flex items-center">
                 <Shield size={14} className="mr-2 text-green-500" /> Security Policies
              </h3>
              <div className="space-y-3">
                 <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">API Key Required</span>
                    <span className="text-xs font-bold text-green-600">ON</span>
                 </div>
                 <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Request Throttling</span>
                    <span className="text-xs font-bold text-gray-400">10k / min</span>
                 </div>
                 <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">CORS Support</span>
                    <span className="text-xs font-bold text-green-600">ENABLED</span>
                 </div>
              </div>
              <button className="w-full mt-6 py-2 border rounded text-xs font-bold text-[#0073bb] hover:bg-gray-50">Edit Usage Plan</button>
           </div>

           <div className="bg-orange-50 border border-orange-200 rounded-lg p-6">
              <div className="flex items-center space-x-2 mb-2">
                 <Zap className="text-orange-600" size={16} />
                 <h3 className="text-sm font-bold text-orange-900">Streaming Optimization</h3>
              </div>
              <p className="text-xs text-orange-800 leading-relaxed">Your API Gateway is connected to **Video Transcoder clusters**. WebSocket manifests are pushing real-time updates to connected players.</p>
           </div>
        </div>
      </div>
    </div>
  );
};
