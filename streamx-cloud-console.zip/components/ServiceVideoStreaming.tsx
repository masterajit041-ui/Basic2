
import React, { useState, useEffect } from 'react';
import { 
  Users, Activity, Globe, Cpu, RefreshCw, Video, Monitor, Zap, Clock, CheckCircle, Radio
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { useNotifications } from '../App';

// Simulated Live Traffic Data
const generateTrafficData = () => {
  return Array.from({ length: 20 }, (_, i) => ({
    time: `${i}:00`,
    viewers: 500 + Math.floor(Math.random() * 1000),
    bandwidth: 2.5 + Math.random() * 5
  }));
};

const MOCK_JOBS = [
  { id: 'job-9821', file: 'trailer_4k_raw.mp4', progress: 100, status: 'Completed', format: 'HLS' },
  { id: 'job-9822', file: 'episode_10_prod.mov', progress: 42, status: 'Processing', format: 'DASH' },
  { id: 'job-9823', file: 'live_ingest_feed_01', progress: 0, status: 'Queued', format: 'HLS' },
];

const MOCK_CHANNELS = [
  { id: 'ch-live-01', name: 'Main News Stream', ingest: 'rtmp://ingest.streamx.com/live/main', status: 'Running', health: 'Excellent' },
  { id: 'ch-live-02', name: 'Sports Hub 2', ingest: 'rtmp://ingest.streamx.com/live/sports2', status: 'Idle', health: '-' },
];

export const ServiceVideoStreaming: React.FC = () => {
  const { addNotification } = useNotifications();
  const [data, setData] = useState(generateTrafficData());
  const [activeTab, setActiveTab] = useState<'monitoring' | 'jobs' | 'live'>('monitoring');
  const [isDeploying, setIsDeploying] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setData(prev => {
        const newData = [...prev.slice(1)];
        newData.push({
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          viewers: 500 + Math.floor(Math.random() * 1500),
          bandwidth: 3.0 + Math.random() * 6
        });
        return newData;
      });
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleDeployStack = () => {
    setIsDeploying(true);
    addNotification('Streaming', 'Scaling global ingest infrastructure...', 'info');
    setTimeout(() => {
      setIsDeploying(false);
      addNotification('Streaming', 'Infrastructure ready for peak traffic.', 'success');
    }, 4000);
  };

  return (
    <div className="flex flex-col h-full bg-[#f8f9fa] overflow-y-auto custom-scrollbar">
      <div className="bg-[#232f3e] text-white p-8 border-b border-white/5">
        <div className="flex justify-between items-start">
           <div>
              <div className="flex items-center space-x-2 text-red-500 mb-2">
                 <Video size={20} className="animate-pulse" />
                 <span className="text-xs font-bold uppercase tracking-widest">Enterprise Video Delivery</span>
              </div>
              <h1 className="text-3xl font-extrabold tracking-tight">StreamX Video Service</h1>
           </div>
           <button onClick={handleDeployStack} disabled={isDeploying} className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded font-bold text-sm shadow-lg flex items-center space-x-2 transition-all active:scale-95 disabled:opacity-50">
              {isDeploying ? <RefreshCw className="animate-spin" size={16} /> : <Zap size={16} />}
              <span>{isDeploying ? 'Scaling...' : 'Scale Infrastructure'}</span>
           </button>
        </div>

        <div className="flex space-x-8 mt-8 border-b border-white/10">
           {['monitoring', 'jobs', 'live'].map((t) => (
              <button 
                key={t} onClick={() => setActiveTab(t as any)}
                className={`pb-2 text-sm font-bold border-b-2 transition-all capitalize ${activeTab === t ? 'text-orange-500 border-orange-500' : 'text-gray-400 border-transparent hover:text-white'}`}
              >{t === 'live' ? 'Live Channels' : t}</button>
           ))}
        </div>
      </div>

      <div className="p-8 space-y-6">
        {activeTab === 'monitoring' ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
               {[
                 { label: 'Live Viewers', value: data[data.length-1].viewers.toLocaleString(), icon: Users, color: 'text-blue-600' },
                 { label: 'Network Egress', value: `${data[data.length-1].bandwidth.toFixed(2)} Gbps`, icon: Activity, color: 'text-orange-600' },
                 { label: 'Edge POPs', value: '42 Active', icon: Globe, color: 'text-purple-600' },
                 { label: 'Avg Latency', value: '18ms', icon: Cpu, color: 'text-green-600' },
               ].map((stat, idx) => (
                 <div key={idx} className="bg-white p-6 border rounded shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between mb-2">
                       <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{stat.label}</p>
                       <stat.icon size={16} className={stat.color} />
                    </div>
                    <p className="text-2xl font-black text-gray-800">{stat.value}</p>
                 </div>
               ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
               <div className="bg-white p-6 border rounded shadow-sm h-80 flex flex-col">
                  <h3 className="text-sm font-bold text-gray-700 mb-4 flex items-center space-x-2"><Monitor size={16} className="text-blue-500" /><span>Viewer Concurrency</span></h3>
                  <div className="flex-1">
                     <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={data}>
                           <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f1f1" />
                           <XAxis dataKey="time" hide />
                           <YAxis fontSize={10} axisLine={false} tickLine={false} />
                           <Tooltip />
                           <Area type="monotone" dataKey="viewers" stroke="#3b82f6" fillOpacity={0.1} fill="#3b82f6" strokeWidth={3} />
                        </AreaChart>
                     </ResponsiveContainer>
                  </div>
               </div>
               <div className="bg-white p-6 border rounded shadow-sm h-80 flex flex-col">
                  <h3 className="text-sm font-bold text-gray-700 mb-4 flex items-center space-x-2"><Activity size={16} className="text-red-500" /><span>Bitrate Egress (Global)</span></h3>
                  <div className="flex-1">
                     <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={data}>
                           <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f1f1" />
                           <XAxis dataKey="time" hide />
                           <YAxis fontSize={10} axisLine={false} tickLine={false} unit=" Gb" />
                           <Tooltip />
                           <Line type="monotone" dataKey="bandwidth" stroke="#ef4444" strokeWidth={3} dot={false} />
                        </LineChart>
                     </ResponsiveContainer>
                  </div>
               </div>
            </div>
          </>
        ) : activeTab === 'jobs' ? (
          <div className="bg-white border rounded shadow-sm overflow-hidden">
             <table className="w-full text-left text-sm">
                <thead className="bg-gray-50 border-b font-bold text-[10px] uppercase text-gray-500">
                   <tr><th className="p-4">Job ID</th><th className="p-4">Source</th><th className="p-4">Progress</th><th className="p-4">Status</th></tr>
                </thead>
                <tbody className="divide-y">
                   {MOCK_JOBS.map(job => (
                      <tr key={job.id} className="hover:bg-gray-50">
                         <td className="p-4 font-mono text-xs">{job.id}</td>
                         <td className="p-4 text-gray-700 font-bold">{job.file}</td>
                         <td className="p-4">
                            <div className="w-32 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                               <div className="h-full bg-orange-500 transition-all duration-1000" style={{ width: `${job.progress}%` }} />
                            </div>
                         </td>
                         <td className="p-4 flex items-center space-x-2">
                            {job.status === 'Completed' ? <CheckCircle size={14} className="text-green-500" /> : <Clock size={14} className="text-blue-500 animate-spin" />}
                            <span className="text-xs font-bold">{job.status}</span>
                         </td>
                      </tr>
                   ))}
                </tbody>
             </table>
          </div>
        ) : (
          <div className="bg-white border rounded shadow-sm overflow-hidden">
             <div className="bg-gray-50 px-6 py-4 border-b flex justify-between items-center">
                <h3 className="text-sm font-bold text-gray-800 flex items-center space-x-2"><Radio size={16} className="text-red-600"/><span>Active Live Inputs</span></h3>
                <button className="text-[10px] bg-red-600 text-white px-2 py-1 rounded font-bold uppercase">New Channel</button>
             </div>
             <div className="p-0">
                <table className="w-full text-left text-sm">
                   <thead className="bg-gray-50/50 border-b font-bold text-[10px] uppercase text-gray-500">
                      <tr><th className="p-4">Channel Name</th><th className="p-4">Ingest URL</th><th className="p-4">Health</th><th className="p-4">Status</th></tr>
                   </thead>
                   <tbody className="divide-y">
                      {MOCK_CHANNELS.map(ch => (
                         <tr key={ch.id} className="hover:bg-gray-50">
                            <td className="p-4 font-bold text-[#0073bb]">{ch.name}</td>
                            <td className="p-4 font-mono text-xs text-gray-400 truncate max-w-xs">{ch.ingest}</td>
                            <td className="p-4"><span className={`text-[10px] font-bold ${ch.health === 'Excellent' ? 'text-green-600' : 'text-gray-300'}`}>{ch.health}</span></td>
                            <td className="p-4">
                               <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${ch.status === 'Running' ? 'bg-green-100 text-green-700 animate-pulse' : 'bg-gray-100 text-gray-500'}`}>{ch.status}</span>
                            </td>
                         </tr>
                      ))}
                   </tbody>
                </table>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};
