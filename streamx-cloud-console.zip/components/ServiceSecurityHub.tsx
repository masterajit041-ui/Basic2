
import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  ShieldAlert, 
  Cpu, 
  Lock, 
  Key, 
  RefreshCw, 
  Activity, 
  CheckCircle, 
  AlertCircle,
  Fingerprint,
  Terminal,
  Server
} from 'lucide-react';
import { useNotifications } from '../App';

export const ServiceSecurityHub: React.FC = () => {
  const { addNotification } = useNotifications();
  const [isScanning, setIsScanning] = useState(false);
  const [lastScan, setLastScan] = useState<string>(new Date().toLocaleString());
  const [firmwareStatus, setFirmwareStatus] = useState<'Secure' | 'Warning'>('Secure');

  const handleDeepScan = () => {
    setIsScanning(true);
    addNotification('Security', 'Initiating Deep Hardware Firmware Scan...', 'info');
    setTimeout(() => {
      setIsScanning(false);
      setLastScan(new Date().toLocaleString());
      addNotification('Security', 'Firmware scan complete. No tampering detected.', 'success');
    }, 4000);
  };

  const MOCK_SECURITY_CHECKS = [
    { name: 'Hardware Root of Trust', status: 'Verified', provider: 'Nitro Chip V3', icon: Cpu },
    { name: 'UEFI Secure Boot', status: 'Enabled', provider: 'SecureBoot v2.1', icon: Lock },
    { name: 'TPM 2.0 State', status: 'Active', provider: 'TPM Hardware Module', icon: Key },
    { name: 'Kernel Integrity', status: 'Verified', provider: 'Runtime Watcher', icon: Activity },
  ];

  return (
    <div className="flex flex-col h-full bg-[#f8f9fa] overflow-y-auto custom-scrollbar">
      {/* Header */}
      <div className="bg-[#1b2531] text-white p-8 border-b border-yellow-500/20">
        <div className="flex justify-between items-center">
           <div>
              <div className="flex items-center space-x-2 text-yellow-500 mb-2">
                 <ShieldCheck size={20} />
                 <span className="text-xs font-bold uppercase tracking-widest">Enterprise Shield Active</span>
              </div>
              <h1 className="text-3xl font-extrabold tracking-tight">Security Hub</h1>
              <p className="text-gray-400 mt-2 max-w-lg text-sm">
                Real-time firmware integrity monitoring and hardware protection. Secure your underlying physical infrastructure from tampering.
              </p>
           </div>
           <button 
             onClick={handleDeepScan}
             disabled={isScanning}
             className="bg-yellow-600 hover:bg-yellow-700 text-white px-8 py-3 rounded font-bold text-sm shadow-xl flex items-center space-x-3 transition-all active:scale-95 disabled:opacity-50"
           >
              {isScanning ? <RefreshCw className="animate-spin" size={18} /> : <Fingerprint size={18} />}
              <span>{isScanning ? 'Scanning Hardware...' : 'Run Deep Integrity Scan'}</span>
           </button>
        </div>
      </div>

      <div className="p-8 space-y-8">
        {/* Status Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
           {MOCK_SECURITY_CHECKS.map((check, idx) => (
             <div key={idx} className="bg-white p-6 border rounded-xl shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-2 opacity-5 group-hover:opacity-10 transition-opacity">
                   <check.icon size={64} />
                </div>
                <div className="flex items-center space-x-3 mb-4">
                   <div className="p-2 bg-yellow-50 text-yellow-600 rounded-lg">
                      <check.icon size={20} />
                   </div>
                   <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">{check.name}</h3>
                </div>
                <div className="flex items-baseline space-x-2">
                   <p className="text-2xl font-black text-gray-800">{check.status}</p>
                   <p className="text-[10px] text-green-600 font-bold uppercase">Ready</p>
                </div>
                <p className="text-[10px] text-gray-400 mt-2 font-mono">{check.provider}</p>
             </div>
           ))}
        </div>

        {/* Firmware Integrity Console */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
           <div className="lg:col-span-2 space-y-6">
              <div className="bg-white border rounded-xl shadow-sm overflow-hidden">
                 <div className="bg-gray-50 px-6 py-4 border-b flex items-center justify-between">
                    <h3 className="text-sm font-bold text-gray-700 flex items-center space-x-2">
                       <Terminal size={16} className="text-gray-500" />
                       <span>Hardware Attestation Logs</span>
                    </h3>
                    <span className="text-[10px] text-gray-400">Last Scan: {lastScan}</span>
                 </div>
                 <div className="p-6 bg-[#0d1117] font-mono text-xs text-green-400 h-80 overflow-y-auto custom-scrollbar shadow-inner">
                    <p className="opacity-50 mb-2">// StreamX Hardware Security Module Initializing...</p>
                    <p>[OK] Nitro v3 Security Chip detected: ID_NX_7712</p>
                    <p>[OK] Root Certificate chain verified up to Global Trust CA</p>
                    <p>[OK] TPM PCR-0 values match expected baseline</p>
                    <p>[OK] Firmware signature SHA-256: 4f1a...92bc (STABLE)</p>
                    <p className="text-yellow-400">[INFO] Periodic background attestation check successful</p>
                    <p>[OK] Secure Boot policy: Strict Enforcement</p>
                    <p>[OK] Memory encryption keys rotated</p>
                    <p className="text-blue-400 mt-2 animate-pulse cursor-default">_ WAITING FOR NEW DATA _</p>
                 </div>
              </div>
           </div>

           <div className="space-y-6">
              <div className="bg-white p-6 border rounded-xl shadow-sm">
                 <h3 className="text-sm font-bold text-gray-800 mb-6 flex items-center space-x-2">
                    <ShieldCheck size={18} className="text-green-600" />
                    <span>Compliance Status</span>
                 </h3>
                 <div className="space-y-6">
                    <div className="flex items-center justify-between">
                       <span className="text-sm text-gray-600">FIPS 140-3 Mode</span>
                       <span className="px-2 py-1 bg-green-100 text-green-700 rounded text-[10px] font-bold uppercase">Verified</span>
                    </div>
                    <div className="flex items-center justify-between">
                       <span className="text-sm text-gray-600">Hardware Encryption</span>
                       <span className="px-2 py-1 bg-green-100 text-green-700 rounded text-[10px] font-bold uppercase">AES-256-XTS</span>
                    </div>
                    <div className="flex items-center justify-between">
                       <span className="text-sm text-gray-600">UEFI Revocation List</span>
                       <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-[10px] font-bold uppercase">Updated</span>
                    </div>
                 </div>
                 <div className="h-[1px] bg-gray-100 my-6"></div>
                 <p className="text-xs text-gray-500 italic">
                    All firmware updates are signed by StreamX Engineering and verified by the local Nitro chip before application.
                 </p>
              </div>

              <div className="bg-gradient-to-br from-[#232f3e] to-[#1b2531] p-6 rounded-xl shadow-lg text-white relative overflow-hidden">
                 <div className="absolute -bottom-4 -right-4 opacity-10">
                    <Server size={100} />
                 </div>
                 <h3 className="font-bold text-sm text-yellow-500 mb-2">Host Protection</h3>
                 <p className="text-xs text-gray-400 leading-relaxed">
                    Physical host servers are protected by physical chassis intrusion detection and localized memory encryption.
                 </p>
                 <button className="mt-6 w-full py-2 bg-white/10 hover:bg-white/20 rounded text-xs font-bold transition-all">
                    View Hardware Specs
                 </button>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};
