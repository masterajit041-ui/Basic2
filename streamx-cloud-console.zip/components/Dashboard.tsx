
import React, { useState, useEffect } from 'react';
import { Activity, Wallet, ShieldCheck, Clock, HardDrive, Globe, Lock, Users, Server, Box, AlertCircle, TrendingUp, Zap, Network, ChevronRight } from 'lucide-react';
import { ServiceType, UserRole } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { COST_DATA, INITIAL_INSTANCES, INITIAL_BUCKETS, INITIAL_VPCS } from '../constants';
import { useNotifications } from '../App';

interface DashboardProps {
  onChangeView: (view: ServiceType) => void;
  role: UserRole;
}

const Widget = ({ title, children, className = '', restricted = false, subtitle = '', accentColor = 'bg-orange-500' }: { title: string, children?: React.ReactNode, className?: string, restricted?: boolean, subtitle?: string, accentColor?: string }) => (
  <div className={`bg-white/80 backdrop-blur-lg border border-white/40 rounded-2xl shadow-[0_8px_32px_rgba(31,38,135,0.07)] p-6 md:p-8 flex flex-col relative overflow-hidden transition-all hover:shadow-[0_20px_40px_rgba(0,0,0,0.05)] hover:-translate-y-1 group ${className}`}>
    <div className={`absolute top-0 left-0 w-full h-1.5 ${accentColor} opacity-70 group-hover:opacity-100 transition-opacity`}></div>
    <div className="flex justify-between items-start mb-6">
        <div>
            <h3 className="font-black text-xl text-[#1e293b] tracking-tight">{title}</h3>
            {subtitle && <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">{subtitle}</p>}
        </div>
        {restricted && (
          <div className="p-2 bg-slate-100 rounded-xl text-slate-400">
            <Lock size={16} />
          </div>
        )}
    </div>
    <div className="flex-1">
        {children}
    </div>
  </div>
);

export const Dashboard: React.FC<DashboardProps> = ({ onChangeView, role }) => {
  const { notifications } = useNotifications();
  const [userCount, setUserCount] = useState(0);

  useEffect(() => {
    const raw = localStorage.getItem('streamx_cloud_database');
    if (raw) {
        try {
            const users = JSON.parse(raw);
            setUserCount(users.length);
        } catch (e) {
            setUserCount(0);
        }
    }
  }, []);

  const isAdmin = role === 'admin';

  return (
    <div className="p-6 md:p-10 lg:p-12 xl:p-16 space-y-10 overflow-y-auto h-full custom-scrollbar bg-[#f8fafc] max-w-[1920px] mx-auto">
      {isAdmin && (
        <div className="bg-gradient-to-r from-orange-600 via-orange-500 to-amber-500 p-[1px] rounded-2xl shadow-xl animate-in slide-in-from-top duration-500">
             <div className="bg-white/95 backdrop-blur-sm py-3.5 px-8 rounded-[15px] flex items-center justify-between">
                <div className="flex items-center space-x-4">
                    <div className="p-2 bg-orange-100 rounded-xl text-orange-600 shadow-sm">
                      <ShieldCheck size={20} />
                    </div>
                    <div>
                      <span className="text-[11px] font-black text-slate-800 uppercase tracking-[0.2em] block">StreaX Privileged Console</span>
                      <span className="text-[9px] text-slate-400 font-bold uppercase">Root Access: Authenticated</span>
                    </div>
                </div>
                <div className="hidden md:flex items-center space-x-8">
                    <div className="flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                      <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Global Status: OK</span>
                    </div>
                    <div className="h-8 w-px bg-slate-200"></div>
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Node: Cluster-Alpha-01</span>
                </div>
             </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
            <h1 className="text-4xl lg:text-5xl font-black text-slate-900 tracking-tighter">Console Home</h1>
            <p className="text-base text-slate-400 font-medium mt-1">Fleet Management & Infrastructure Monitoring</p>
        </div>
        <div className={`text-xs px-4 py-2 rounded-xl border font-black uppercase tracking-widest flex items-center space-x-2 ${isAdmin ? 'bg-red-50 text-red-600 border-red-100' : 'bg-white text-slate-500 border-slate-200 shadow-sm'}`}>
          <div className={`w-2 h-2 rounded-full ${isAdmin ? 'bg-red-600 animate-pulse' : 'bg-slate-400'}`}></div>
          <span>{isAdmin ? 'System Administrator' : 'IAM Identity'}</span>
        </div>
      </div>

      {isAdmin && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
            {[
              { label: 'Cloud Instances', val: INITIAL_INSTANCES.length, icon: Server, color: 'text-blue-500', bg: 'bg-blue-50', view: ServiceType.EC2 },
              { label: 'Global S3 Buckets', val: INITIAL_BUCKETS.length, icon: Box, color: 'text-emerald-500', bg: 'bg-emerald-50', view: ServiceType.S3 },
              { label: 'Private Networks', val: INITIAL_VPCS.length, icon: Network, color: 'text-violet-500', bg: 'bg-violet-50', view: ServiceType.VPC },
              { label: 'Identities Found', val: userCount, icon: Users, color: 'text-rose-500', bg: 'bg-rose-50', view: ServiceType.IAM }
            ].map((stat, i) => (
              <div key={i} onClick={() => onChangeView(stat.view)} className="bg-white border border-slate-200 p-8 rounded-3xl flex items-center justify-between shadow-sm cursor-pointer transition-all hover:scale-[1.03] hover:shadow-2xl hover:border-slate-300 group">
                  <div>
                      <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-2">{stat.label}</p>
                      <p className="text-4xl font-black text-slate-900 tracking-tight">{stat.val}</p>
                  </div>
                  <div className={`p-5 ${stat.bg} ${stat.color} rounded-2xl group-hover:scale-110 transition-transform shadow-sm`}>
                    <stat.icon size={28} />
                  </div>
              </div>
            ))}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 2xl:grid-cols-3 gap-8">
        <Widget title="Quick Navigation" subtitle="Recent History" accentColor="bg-blue-500">
           <div className="space-y-3">
             {[
               { name: 'EC2', desc: 'Elastic Compute Nodes', type: ServiceType.EC2, icon: Server },
               { name: 'S3', desc: 'Secure Object Storage', type: ServiceType.S3, icon: Box },
               { name: 'VPC', desc: 'Virtual Networking', type: ServiceType.VPC, icon: Network }
             ].map(s => (
               <button key={s.name} onClick={() => onChangeView(s.type)} className="w-full group flex items-center justify-between p-4 rounded-2xl hover:bg-slate-50 border border-transparent hover:border-slate-100 transition-all">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-500 group-hover:bg-blue-100 group-hover:text-blue-600 transition-all">
                       <s.icon size={20} />
                    </div>
                    <div className="text-left">
                      <p className="text-base font-black text-slate-800 group-hover:text-blue-600">{s.name}</p>
                      <p className="text-[11px] text-slate-400 font-medium">{s.desc}</p>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-slate-300 group-hover:text-blue-500 transition-all transform group-hover:translate-x-1" />
               </button>
             ))}
             {isAdmin && (
                <button onClick={() => onChangeView(ServiceType.IAM)} className="w-full group flex items-center justify-between p-4 rounded-2xl hover:bg-red-50 border border-transparent hover:border-red-100 transition-all mt-4 bg-red-50/20">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center text-red-500 transition-all">
                       <Users size={20} />
                    </div>
                    <div className="text-left">
                      <p className="text-base font-black text-red-800">IAM Manager</p>
                      <p className="text-[11px] text-red-400 font-bold uppercase tracking-tight italic">Secure Identity Pool</p>
                    </div>
                  </div>
                  <ShieldCheck size={18} className="text-red-300 group-hover:text-red-600" />
                </button>
             )}
           </div>
        </Widget>

        <Widget title="Global Telemetry" subtitle="Real-time Stream" accentColor="bg-emerald-500">
           <div className="space-y-5 max-h-[300px] overflow-y-auto custom-scrollbar pr-3">
             {notifications.length > 0 ? (
               notifications.slice(0, 6).map(n => (
                <div key={n.id} className="flex space-x-5 items-start p-4 rounded-2xl hover:bg-slate-50 transition-all border border-transparent hover:border-slate-100">
                   <div className={`w-2.5 h-2.5 rounded-full mt-2.5 shrink-0 ${
                     n.type === 'success' ? 'bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.5)]' :
                     n.type === 'warning' ? 'bg-amber-500 shadow-[0_0_12px_rgba(245,158,11,0.5)]' : 'bg-blue-500'
                   }`} />
                   <div className="flex-1">
                      <p className="text-sm font-black text-slate-800 leading-snug mb-1.5">{n.message}</p>
                      <div className="flex items-center space-x-3">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center">
                          <Clock size={10} className="mr-1" /> {n.time}
                        </span>
                        <span className="h-1 w-1 rounded-full bg-slate-300"></span>
                        <span className="text-[10px] font-black text-slate-500 bg-slate-100 px-2 py-0.5 rounded uppercase">{n.title}</span>
                      </div>
                   </div>
                </div>
               ))
             ) : (
                <div className="h-56 flex flex-col items-center justify-center text-slate-300">
                  <Activity size={48} className="opacity-10 mb-4 animate-pulse" />
                  <p className="text-[11px] font-black uppercase tracking-widest">No active signals</p>
                </div>
             )}
           </div>
        </Widget>

        <Widget title="Cost Dynamics" subtitle="Predictive Analytics" accentColor="bg-violet-500" restricted={!isAdmin} className="lg:col-span-2 2xl:col-span-1">
            <div className="h-64 flex flex-col justify-between">
              <div className="flex-1 cursor-pointer" onClick={() => isAdmin && onChangeView(ServiceType.BILLING)}>
                <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={COST_DATA}>
                        <defs>
                          <linearGradient id="colorCostDashPC" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.2}/>
                            <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="name" hide />
                        <YAxis hide />
                        <Tooltip 
                          contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)', background: 'rgba(255,255,255,0.9)' }} 
                          labelStyle={{ fontWeight: 'black', color: '#1e293b' }}
                        />
                        <Area type="monotone" dataKey="cost" stroke="#8b5cf6" fill="url(#colorCostDashPC)" strokeWidth={5} />
                    </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-6 flex justify-between items-center bg-violet-50 p-4 rounded-2xl border border-violet-100 group cursor-pointer hover:bg-violet-100 transition-colors">
                <div>
                  <span className="text-[10px] font-black text-violet-400 uppercase block tracking-widest mb-1">Monthly Forecast</span>
                  <span className="text-2xl font-black text-violet-900">$1,950.00</span>
                </div>
                <div className="p-2 bg-white rounded-xl shadow-sm text-violet-600">
                  <TrendingUp size={20} />
                </div>
              </div>
            </div>
        </Widget>
      </div>

      <div className="space-y-6 pt-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-black text-slate-900 tracking-tight flex items-center space-x-3">
            <Zap size={24} className="text-amber-500 fill-amber-500" />
            <span>Infrastructure Launchpad</span>
          </h2>
          <button className="text-xs font-black text-blue-600 hover:underline uppercase tracking-widest">View All Services</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
                { title: 'Launch Compute', desc: 'Virtual Elastic Nodes', icon: Server, view: ServiceType.EC2, color: 'text-blue-500', bg: 'bg-blue-50' },
                { title: 'Serverless Hub', desc: 'Logic at the Edge', icon: Zap, view: ServiceType.LAMBDA, color: 'text-amber-500', bg: 'bg-amber-50' },
                { title: 'Global Storage', desc: 'Infinite Data Lake', icon: HardDrive, view: ServiceType.S3, color: 'text-emerald-500', bg: 'bg-emerald-50' },
                { title: 'VPC Gateway', desc: 'Cloud Network Isolation', icon: Network, view: ServiceType.VPC, color: 'text-violet-500', bg: 'bg-violet-50' },
            ].map((item, idx) => (
                <div 
                  key={idx} 
                  onClick={() => onChangeView(item.view)}
                  className="bg-white border border-slate-200 p-6 rounded-3xl shadow-sm hover:shadow-2xl hover:border-slate-300 hover:-translate-y-1.5 transition-all cursor-pointer group flex flex-col justify-between h-48"
                >
                    <div className="flex items-center justify-between">
                        <div className={`p-4 rounded-2xl ${item.bg} ${item.color} group-hover:scale-110 transition-transform shadow-sm`}>
                          <item.icon size={24} />
                        </div>
                        <ChevronRight size={20} className="text-slate-200 group-hover:text-slate-400 transition-colors" />
                    </div>
                    <div>
                      <div className="font-black text-slate-900 tracking-tight text-lg mb-1">{item.title}</div>
                      <div className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">{item.desc}</div>
                    </div>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};
