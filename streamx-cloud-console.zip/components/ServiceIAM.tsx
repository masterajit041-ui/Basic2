
import React, { useState, useEffect } from 'react';
import { Users, Trash2, Search, RefreshCw, ShieldCheck, User as UserIcon, Lock, Check, X } from 'lucide-react';
import { useNotifications } from '../App';
import { ServiceType } from '../types';

export const ServiceIAM: React.FC = () => {
  const { addNotification } = useNotifications();
  const [db, setDb] = useState<any[]>([]);
  const [search, setSearch] = useState('');

  const DATABASE_KEY = 'streamx_cloud_database';

  const loadDb = () => {
    const raw = localStorage.getItem(DATABASE_KEY);
    setDb(raw ? JSON.parse(raw) : []);
  };

  useEffect(() => { loadDb(); }, []);

  const togglePermission = (email: string, service: ServiceType) => {
    const updated = db.map(u => {
      if (u.email === email) {
        if (u.accountId === '001') return u; 
        const perms = u.permissions || [];
        const newPerms = perms.includes(service) 
          ? perms.filter((p: string) => p !== service)
          : [...perms, service];
        return { ...u, permissions: newPerms };
      }
      return u;
    });
    localStorage.setItem(DATABASE_KEY, JSON.stringify(updated));
    setDb(updated);
    addNotification('IAM', `Permission for ${service} updated at ${new Date().toLocaleTimeString()}.`, 'info');
  };

  const filteredDb = db.filter(u => 
    u.email.toLowerCase().includes(search.toLowerCase()) || 
    u.username.toLowerCase().includes(search.toLowerCase())
  );

  const PURCHASABLE = [ServiceType.EC2, ServiceType.S3, ServiceType.RDS, ServiceType.VPC, ServiceType.LAMBDA];

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="px-6 py-6 border-b border-gray-200">
        <h1 className="text-2xl font-bold text-[#161e2d] flex items-center">
          <Users className="mr-2 text-[#ec7211]" /> IAM - Directory
        </h1>
        <div className="flex justify-between items-center mt-6">
          <div className="flex-1 max-w-xl relative">
            <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
            <input type="text" placeholder="Search users..." className="w-full pl-10 pr-4 py-2 border rounded text-sm outline-none" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <button onClick={loadDb} className="ml-4 p-2 border rounded hover:bg-gray-50"><RefreshCw size={20} /></button>
        </div>
      </div>

      <div className="p-6 overflow-auto">
        <div className="border border-gray-300 rounded shadow-sm">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 border-b font-bold text-[10px] uppercase text-gray-500">
              <tr>
                <th className="p-4">User</th>
                <th className="p-4">Auth Details</th>
                <th className="p-4">Service Access Management</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {filteredDb.map((user, idx) => (
                <tr key={idx} className="hover:bg-gray-50 transition-colors">
                  <td className="p-4">
                    <div className="flex items-center space-x-3">
                       <div className={`w-8 h-8 rounded-full flex items-center justify-center ${user.role === 'admin' ? 'bg-orange-100 text-orange-600' : 'bg-blue-100 text-blue-600'}`}><UserIcon size={16} /></div>
                       <div><p className="font-bold">{user.username}</p><p className="text-[10px] text-gray-400">ID: {user.accountId}</p></div>
                    </div>
                  </td>
                  <td className="p-4">
                    <p className="font-mono text-xs">{user.email}</p>
                    <p className="text-[10px] text-gray-400">PW: {user.password}</p>
                  </td>
                  <td className="p-4">
                    <div className="flex flex-wrap gap-2">
                       {PURCHASABLE.map(s => {
                          const active = (user.permissions || []).includes(s) || user.role === 'admin';
                          return (
                            <button 
                              key={s} disabled={user.role === 'admin'}
                              onClick={() => togglePermission(user.email, s)}
                              className={`px-2 py-1 rounded text-[10px] font-bold border flex items-center space-x-1 transition-all ${active ? 'bg-green-50 text-green-700 border-green-200' : 'bg-gray-50 text-gray-400 border-gray-200'}`}
                            >
                               {active ? <Check size={10} /> : <X size={10} />}
                               <span>{s}</span>
                            </button>
                          );
                       })}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
