
import React, { useState, useEffect } from 'react';
import { Globe, Activity, Zap, Shield, Share2, Server, Search, RefreshCw, Layers } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import { useNotifications } from '../App';

const MOCK_CDN_DATA = Array.from({ length: 24 }, (_, i) => ({
  time: `${i}:00`,
  hits: 8000 + Math.floor(Math.random() * 5000),
  misses: 200 + Math.floor(Math.random() * 800)
}));

export const ServiceCDN: React.FC = () => {
  const { addNotification } = useNotifications();
  const [data, setData] = useState(MOCK_CDN_DATA);

  const handlePurgeCache = () => {
    addNotification('CDN', 'Invalidating edge caches worldwide...', 'info');
    setTimeout(() => {
      addNotification('CDN', 'Global cache purge complete. Content will refresh at next request.', 'success');
    }, 3000);
  };

  return (
    <div className="flex flex-col h-full bg-[#f8f9fa] overflow-y-auto custom-scrollbar">
      <div className="bg-white p-6 border-b border-gray-200 flex justify-between items-center">
        <div>
           <h1 className="text-2xl font-bold text-[#161e2d] flex items-center">
              <Share2 className="mr-2 text-blue-500" /> CDN Distributions
           </h1>
           <p className="text-sm text-gray-500">CloudFront-like Global Content Delivery</p>
        </div>
        <div className="flex space-x-3">
           <button onClick={handlePurgeCache} className="bg-white border border-gray-300 px-4 py-2 rounded text-sm font-bold text-gray-700 hover:bg-gray-50">Invalidate Cache</button>
           <button className="bg-[#ec7211] text-white px-4 py-2 rounded text-sm font-bold hover:bg-orange-600 shadow-sm">Create Distribution</button>
        </div>
      </div>

      <div className="p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
           {[
             { label: 'Cache Hit Ratio', value: '94.2%', color: 'text-green-600', icon: Zap },
             { label: 'Total Requests', value: '1.2M', color: 'text-blue-600', icon: Activity },
             { label: 'Egress Traffic', value: '4.8 TB', color: 'text-purple-600', icon: Globe },
             { label: 'WAF Blocked', value: '12', color: 'text-red-600', icon: Shield },
           ].map((stat, idx) => (
             <div key={idx} className="bg-white p-6 border rounded shadow-sm">
                <div className="flex justify-between items-center mb-1">
                   <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{stat.label}</p>
                   <stat.icon size={16} className={stat.color} />
                </div>
                <p className="text-2xl font-black text-gray-800">{stat.value}</p>
             </div>
           ))}
        </div>

        <div className="bg-white border rounded shadow-sm p-6">
           <h3 className="text-sm font-bold text-gray-700 mb-6">Request Traffic (Cache Hits vs Misses)</h3>
           <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                 <AreaChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="time" hide />
                    <YAxis fontSize={10} axisLine={false} tickLine={false} />
                    <Tooltip />
                    <Area type="monotone" dataKey="hits" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.1} />
                    <Area type="monotone" dataKey="misses" stroke="#ef4444" fill="#ef4444" fillOpacity={0.1} />
                 </AreaChart>
              </ResponsiveContainer>
           </div>
        </div>

        <div className="bg-[#1b2531] text-white p-8 rounded-lg shadow-xl relative overflow-hidden">
           <div className="absolute top-0 right-0 p-8 opacity-10">
              <Globe size={200} />
           </div>
           <div className="relative z-10">
              <h2 className="text-xl font-bold mb-2">Global Edge Presence</h2>
              <p className="text-gray-400 text-sm max-w-md">Streaming content is currently cached in 42 cities across 6 continents. User latency from Mumbai is 12ms.</p>
              <div className="mt-8 flex space-x-8">
                 <div className="text-center">
                    <p className="text-2xl font-bold">12ms</p>
                    <p className="text-[10px] text-gray-500 uppercase">Asia</p>
                 </div>
                 <div className="text-center">
                    <p className="text-2xl font-bold">18ms</p>
                    <p className="text-[10px] text-gray-500 uppercase">Europe</p>
                 </div>
                 <div className="text-center">
                    <p className="text-2xl font-bold">15ms</p>
                    <p className="text-[10px] text-gray-500 uppercase">Americas</p>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};
