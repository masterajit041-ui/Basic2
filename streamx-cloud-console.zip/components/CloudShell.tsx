
import React, { useState, useEffect, useRef } from 'react';
import { Terminal as TerminalIcon, X, Maximize2, Minimize2, ChevronRight, Zap } from 'lucide-react';
import { UserSession } from '../types';

interface CloudShellProps {
  isOpen: boolean;
  onClose: () => void;
  session: UserSession;
}

export const CloudShell: React.FC<CloudShellProps> = ({ isOpen, onClose, session }) => {
  const [history, setHistory] = useState<string[]>(['Welcome to StreamX CloudShell.', 'Type "help" to see available commands.']);
  const [input, setInput] = useState('');
  const [isMaximized, setIsMaximized] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history]);

  const processCommand = (cmd: string) => {
    const command = cmd.toLowerCase().trim();
    const newHistory = [...history, `[${session.username}@streamx ~]$ ${cmd}`];

    switch (command) {
      case 'help':
        newHistory.push('Available commands:', '  ls        - List active directories', '  whoami    - Display current user info', '  ec2 list  - List running instances', '  clear     - Clear terminal screen', '  exit      - Close CloudShell');
        break;
      case 'ls':
        newHistory.push('apps/  bin/  config/  logs/  services/');
        break;
      case 'whoami':
        newHistory.push(`User: ${session.username}`, `Role: ${session.role}`, `Account: ${session.accountId}`, `Region: global-core-1`);
        break;
      case 'ec2 list':
        newHistory.push('Fetching EC2 nodes...', 'i-0a1b2c3d4e5f6g7h8   running   t3.micro', 'i-1a2b3c4d5e6f7g8h9   stopped   m5.large');
        break;
      case 'clear':
        setHistory([]);
        return;
      case 'exit':
        onClose();
        return;
      case '':
        break;
      default:
        newHistory.push(`sh: command not found: ${cmd}`);
    }
    setHistory(newHistory);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    processCommand(input);
    setInput('');
  };

  if (!isOpen) return null;

  return (
    <div 
      className={`fixed bottom-0 right-0 bg-[#0d1117] border-t-2 border-[#ec7211] shadow-2xl z-[100] transition-all duration-300 flex flex-col font-mono ${
        isMaximized ? 'w-full h-full' : 'w-full md:w-[600px] h-80'
      }`}
    >
      <div className="bg-[#1b2531] px-4 py-2 flex justify-between items-center text-gray-400 border-b border-white/5">
        <div className="flex items-center space-x-2">
          <TerminalIcon size={14} className="text-[#ec7211]" />
          <span className="text-[10px] font-bold uppercase tracking-widest">CloudShell - {session.username}</span>
        </div>
        <div className="flex items-center space-x-3">
          <button onClick={() => setIsMaximized(!isMaximized)} className="hover:text-white transition-colors">
            {isMaximized ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
          </button>
          <button onClick={onClose} className="hover:text-red-500 transition-colors">
            <X size={16} />
          </button>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-1 text-sm text-green-400 custom-scrollbar">
        {history.map((line, i) => (
          <div key={i} className={line.startsWith('[') ? 'text-blue-400' : ''}>{line}</div>
        ))}
        <form onSubmit={handleSubmit} className="flex items-center mt-2">
          <span className="text-blue-400 mr-2">[{session.username}@streamx ~]$</span>
          <input 
            autoFocus
            type="text" 
            className="flex-1 bg-transparent outline-none text-green-400 border-none p-0 focus:ring-0"
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
        </form>
      </div>

      <div className="bg-black/40 px-4 py-1 flex items-center justify-between text-[9px] text-gray-600 border-t border-white/5">
        <div className="flex items-center space-x-3">
          <span className="flex items-center"><Zap size={10} className="mr-1 text-yellow-600" /> Latency: 14ms</span>
          <span>Region: global-1</span>
        </div>
        <span className="uppercase">StreamX Shell v1.0.4-stable</span>
      </div>
    </div>
  );
};
