
import React from 'react';
import { CreditCard, Receipt, TrendingUp, Download, PieChart, Calendar, AlertCircle, ChevronRight } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { COST_DATA } from '../constants';

const SERVICE_COSTS = [
  { name: 'EC2', cost: 850 },
  { name: 'S3', cost: 120 },
  { name: 'RDS', cost: 450 },
  { name: 'Lambda', cost: 30 },
  { name: 'Data Transfer', cost: 500 },
];

export const ServiceBilling: React.FC = () => {
  return (
    <div className="flex flex-col h-full bg-[#f2f3f3] overflow-y-auto">
      {/* Header */}
      <div className="bg-white px-8 py-6 border-b border-gray-200">
        <h1 className="text-2xl font-bold text-[#161e2d]">Billing and Cost Management</h1>
        <p className="text-sm text-gray-500">Account ID: 1234-5678-9012</p>
      </div>

      <div className="p-8 space-y-6 max-w-7xl mx-auto w-full">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 border rounded shadow-sm">
            <p className="text-xs font-bold text-gray-500 uppercase mb-1">Estimated bill to date</p>
            <p className="text-3xl font-extrabold text-[#161e2d]">$1,950.00</p>
            <div className="mt-4 flex items-center text-xs text-red-600">
              <TrendingUp size={14} className="mr-1" />
              <span>12.5% increase from last month</span>
            </div>
          </div>
          <div className="bg-white p-6 border rounded shadow-sm">
            <p className="text-xs font-bold text-gray-500 uppercase mb-1">Last month's bill</p>
            <p className="text-3xl font-extrabold text-[#161e2d]">$1,732.40</p>
            <button className="mt-4 text-xs font-bold text-[#0073bb] hover:underline flex items-center">
              <Download size={14} className="mr-1" /> View Invoice (PDF)
            </button>
          </div>
          <div className="bg-white p-6 border rounded shadow-sm flex flex-col justify-between">
            <div>
              <p className="text-xs font-bold text-gray-500 uppercase mb-1">Payment Method</p>
              <div className="flex items-center space-x-2 mt-1">
                <CreditCard size={18} className="text-gray-400" />
                <span className="font-bold text-sm">Visa ending in 4242</span>
              </div>
            </div>
            <button className="text-xs font-bold text-[#0073bb] hover:underline text-left mt-4">Manage methods</button>
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-6 border rounded shadow-sm h-80">
            <h3 className="font-bold text-sm mb-6 flex items-center">
              <Calendar size={16} className="mr-2 text-blue-600" /> Monthly Cost Trend
            </h3>
            <div className="h-full pb-8">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={COST_DATA}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} fontSize={12} />
                  <YAxis axisLine={false} tickLine={false} fontSize={12} />
                  <Tooltip />
                  <Line type="monotone" dataKey="cost" stroke="#ec7211" strokeWidth={3} dot={{ r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white p-6 border rounded shadow-sm h-80">
            <h3 className="font-bold text-sm mb-6 flex items-center">
              <PieChart size={16} className="mr-2 text-green-600" /> Cost by Service
            </h3>
            <div className="h-full pb-8">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={SERVICE_COSTS} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#eee" />
                  <XAxis type="number" axisLine={false} tickLine={false} fontSize={10} />
                  <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} fontSize={12} width={80} />
                  <Tooltip />
                  <Bar dataKey="cost" fill="#0073bb" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Alerts & Recommendations */}
        <div className="bg-white border border-yellow-200 rounded shadow-sm overflow-hidden">
          <div className="bg-yellow-50 px-6 py-3 border-b border-yellow-100 flex items-center space-x-2">
            <AlertCircle size={18} className="text-yellow-600" />
            <h3 className="font-bold text-sm text-yellow-900">Savings Recommendations</h3>
          </div>
          <div className="p-6 divide-y divide-gray-100">
            <div className="py-3 flex justify-between items-center group cursor-pointer">
              <div className="flex space-x-4">
                <div className="p-2 bg-blue-50 text-blue-600 rounded">
                  <TrendingUp size={18} />
                </div>
                <div>
                  <p className="text-sm font-bold">Unused Elastic IP addresses</p>
                  <p className="text-xs text-gray-500">You have 2 Elastic IPs not associated with any instance.</p>
                </div>
              </div>
              <div className="flex items-center text-[#0073bb] font-bold text-xs">
                <span>Save $7.20/mo</span>
                <ChevronRight size={14} className="ml-1" />
              </div>
            </div>
            <div className="py-3 flex justify-between items-center group cursor-pointer">
              <div className="flex space-x-4">
                <div className="p-2 bg-green-50 text-green-600 rounded">
                  <Receipt size={18} />
                </div>
                <div>
                  <p className="text-sm font-bold">Reserved Instance Opportunity</p>
                  <p className="text-xs text-gray-500">Convert 3 On-Demand EC2 instances to 1-year RI.</p>
                </div>
              </div>
              <div className="flex items-center text-[#0073bb] font-bold text-xs">
                <span>Save $120.50/mo</span>
                <ChevronRight size={14} className="ml-1" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
