
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { 
  Search, 
  Bell, 
  Settings as SettingsIcon, 
  Grid, 
  HelpCircle, 
  LogOut, 
  Monitor, 
  Languages, 
  Keyboard, 
  Lock,
  ChevronRight,
  Check,
  ShieldCheck,
  ShieldAlert,
  ChevronDown,
  Box,
  Zap,
  Cpu,
  Info,
  Trash2,
  Network,
  ExternalLink,
  Inbox,
  Database,
  PlaySquare,
  Share2,
  DoorOpen,
  ShieldX,
  Terminal as TerminalIcon,
  TableProperties,
  LayoutDashboard,
  CreditCard,
  LifeBuoy
} from 'lucide-react';
import { UserSession, ServiceType } from '../types';
import { useNotifications } from '../App';

interface NavbarProps {
  session: UserSession;
  onLogout: () => void;
  onSearchRedirect: (view: ServiceType) => void;
  onOpenTerminal: () => void;
}

type SettingTab = 'main' | 'display' | 'language' | 'shortcuts' | 'privacy';

const SERVICE_CATALOG = [
  { type: ServiceType.DASHBOARD, label: 'Console Home', icon: LayoutDashboard, category: 'General' },
  { type: ServiceType.EC2, label: 'EC2', icon: Cpu, category: 'Compute', description: 'Virtual Servers' },
  { type: ServiceType.S3, label: 'S3', icon: Box, category: 'Storage', description: 'Object Storage' },
  { type: ServiceType.RDS, label: 'RDS', icon: Database, category: 'Database', description: 'Managed SQL' },
  { type: ServiceType.LAMBDA, label: 'Lambda', icon: Zap, category: 'Compute', description: 'Serverless Functions' },
  { type: ServiceType.IAM, label: 'IAM', icon: ShieldCheck, category: 'Security', description: 'User Management' },
  { type: ServiceType.VPC, label: 'VPC', icon: Network, category: 'Networking', description: 'Virtual Private Cloud' },
  { type: ServiceType.VIDEO_STREAMING, label: 'Video Streaming', icon: PlaySquare, category: 'Media', description: 'Live & On-Demand' },
  { type: ServiceType.CDN, label: 'CDN (CloudFront)', icon: Share2, category: 'Media', description: 'Global Delivery' },
  { type: ServiceType.API_GATEWAY, label: 'API Gateway', icon: DoorOpen, category: 'Networking', description: 'API Management' },
  { type: ServiceType.SECURITY_HUB, label: 'Security Hub', icon: ShieldCheck, category: 'Security', description: 'Firmware Protection' },
  { type: ServiceType.WAF, label: 'WAF & Shield', icon: ShieldX, category: 'Security', description: 'Firewall & DDoS' },
  { type: ServiceType.CLOUDWATCH_LOGS, label: 'CloudWatch Logs', icon: TerminalIcon, category: 'Management', description: 'System Logging' },
  { type: ServiceType.DYNAMODB, label: 'DynamoDB', icon: TableProperties, category: 'Database', description: 'NoSQL Database' },
  { type: ServiceType.BILLING, label: 'Billing', icon: CreditCard, category: 'Management', description: 'Cost Explorer' },
  { type: ServiceType.SUPPORT, label: 'Support', icon: LifeBuoy, category: 'General', description: 'Documentation & Help' },
];

export const Navbar: React.FC<NavbarProps> = ({ session, onLogout, onSearchRedirect, onOpenTerminal }) => {
  const { notifications, addNotification, markAllRead, clearNotifications } = useNotifications();
  const unreadCount = notifications.filter(n => !n.read).length;

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isUserOpen, setIsUserOpen] = useState(false);
  const [isNotifyOpen, setIsNotifyOpen] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const [isRegionOpen, setIsRegionOpen] = useState(false);
  
  const [region, setRegion] = useState('Global (Core)');
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchResults, setShowSearchResults] = useState(false);

  const settingsRef = useRef<HTMLDivElement>(null);
  const userRef = useRef<HTMLDivElement>(null);
  const notifyRef = useRef<HTMLDivElement>(null);
  const regionRef = useRef<HTMLDivElement>(null);
  const servicesRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const refs = [settingsRef, userRef, notifyRef, regionRef, servicesRef, searchRef];
      const setters = [setIsSettingsOpen, setIsUserOpen, setIsNotifyOpen, setIsRegionOpen, setIsServicesOpen, setShowSearchResults];
      refs.forEach((ref, idx) => {
        if (ref.current && !ref.current.contains(event.target as Node)) {
          setters[idx](false);
        }
      });
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredServices = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase();
    return SERVICE_CATALOG.filter(s => 
      s.label.toLowerCase().includes(q) || 
      s.category.toLowerCase().includes(q) ||
      (s.description && s.description.toLowerCase().includes(q))
    ).slice(0, 8);
  }, [searchQuery]);

  const handleSearch = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      if (filteredServices.length > 0) {
        onSearchRedirect(filteredServices[0].type);
        setSearchQuery('');
        setShowSearchResults(false);
      } else if (searchQuery.startsWith('i-')) {
        onSearchRedirect(ServiceType.EC2);
        addNotification('Search', `Locating instance ${searchQuery}...`, 'success');
        setSearchQuery('');
        setShowSearchResults(false);
      } else {
        addNotification('Search', `No matches found for "${searchQuery}"`, 'info');
      }
    }
  };

  const closeAll = () => {
    setIsServicesOpen(false); setIsNotifyOpen(false); 
    setIsSettingsOpen(false); setIsUserOpen(false); setIsRegionOpen(false);
  };

  return (
    <nav className="h-[52px] bg-[#232f3e] text-white flex items-center justify-between px-4 fixed w-full z-50">
      <div className="flex items-center space-x-2 shrink-0">
        <div 
          className="flex items-center cursor-pointer px-3 py-1 rounded hover:bg-white/10 transition-all select-none"
          onClick={() => onSearchRedirect(ServiceType.DASHBOARD)}
        >
          <div className="mr-2 flex items-center justify-center">
            <div className="w-7 h-7 bg-[#ec7211] rounded flex items-center justify-center font-bold text-white text-xs shadow-inner">SX</div>
          </div>
          <span className="text-xl font-extrabold tracking-tighter text-white">streamX</span>
        </div>

        <div className="relative" ref={servicesRef}>
          <div 
            className="flex items-center cursor-pointer group px-3 py-1 rounded hover:bg-white/10 transition-colors ml-1"
            onClick={() => { closeAll(); setIsServicesOpen(!isServicesOpen); }}
          >
            <Grid size={20} className={`transition-colors ${isServicesOpen ? 'text-white' : 'text-gray-400 group-hover:text-white'}`} />
            <span className={`ml-2 font-bold text-sm hidden md:block transition-colors ${isServicesOpen ? 'text-white' : 'group-hover:text-white'}`}>Services</span>
          </div>
          {isServicesOpen && (
            <div className="absolute top-full left-0 mt-3 w-[640px] bg-white text-[#161e2d] shadow-2xl rounded-lg border border-gray-200 overflow-hidden z-[100] p-6 grid grid-cols-3 gap-8 animate-in fade-in slide-in-from-top-2">
               <div>
                  <h3 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">Compute & Storage</h3>
                  <div className="space-y-4">
                     {[ServiceType.EC2, ServiceType.S3, ServiceType.LAMBDA].map(t => {
                        const s = SERVICE_CATALOG.find(sc => sc.type === t)!;
                        return (
                          <div key={t} onClick={() => { onSearchRedirect(t); closeAll(); }} className="flex items-center space-x-3 group cursor-pointer">
                            <s.icon size={18} className="text-orange-500" />
                            <div><p className="text-sm font-bold group-hover:text-orange-600">{s.label}</p><p className="text-[10px] text-gray-500">{s.description}</p></div>
                          </div>
                        );
                     })}
                  </div>
               </div>
               <div>
                  <h3 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">Database & Media</h3>
                  <div className="space-y-4">
                    {[ServiceType.DYNAMODB, ServiceType.VIDEO_STREAMING, ServiceType.CDN].map(t => {
                        const s = SERVICE_CATALOG.find(sc => sc.type === t)!;
                        return (
                          <div key={t} onClick={() => { onSearchRedirect(t); closeAll(); }} className="flex items-center space-x-3 group cursor-pointer">
                            <s.icon size={18} className="text-blue-500" />
                            <div><p className="text-sm font-bold group-hover:text-blue-600">{s.label}</p><p className="text-[10px] text-gray-500">{s.description}</p></div>
                          </div>
                        );
                     })}
                  </div>
               </div>
               <div>
                  <h3 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">Security & Net</h3>
                  <div className="space-y-4">
                    {[ServiceType.VPC, ServiceType.IAM, ServiceType.WAF].map(t => {
                        const s = SERVICE_CATALOG.find(sc => sc.type === t)!;
                        return (
                          <div key={t} onClick={() => { onSearchRedirect(t); closeAll(); }} className="flex items-center space-x-3 group cursor-pointer">
                            <s.icon size={18} className="text-purple-500" />
                            <div><p className="text-sm font-bold group-hover:text-purple-600">{s.label}</p><p className="text-[10px] text-gray-500">{s.description}</p></div>
                          </div>
                        );
                     })}
                  </div>
               </div>
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 max-w-2xl mx-4 hidden md:flex relative group" ref={searchRef}>
        <input 
          type="text" 
          placeholder="Search for services, features, and docs (e.g. 'EC2', 'CDN')" 
          className="w-full h-8 px-3 rounded-sm bg-[#161e2d] border border-[#5d6a7d] text-sm text-gray-200 focus:outline-none focus:border-[#ec7211] focus:ring-1 focus:ring-[#ec7211] placeholder-gray-400"
          value={searchQuery}
          onChange={(e) => { setSearchQuery(e.target.value); setShowSearchResults(e.target.value.length > 0); }}
          onKeyDown={handleSearch}
        />
        <Search className="absolute right-2 top-1.5 text-gray-400 group-hover:text-[#ec7211] transition-colors" size={16} />
        
        {showSearchResults && (
           <div className="absolute top-full left-0 right-0 mt-1 bg-white shadow-2xl rounded-sm border border-gray-200 text-[#161e2d] z-[200] overflow-hidden animate-in fade-in zoom-in-95 duration-100">
              {filteredServices.length > 0 ? (
                <>
                  <div className="px-3 py-2 bg-gray-50 border-b border-gray-100 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Global Suggestions</div>
                  <div className="p-1">
                    {filteredServices.map(service => (
                        <button 
                          key={service.type} 
                          onClick={() => { onSearchRedirect(service.type); setShowSearchResults(false); setSearchQuery(''); }} 
                          className="w-full text-left px-3 py-2.5 hover:bg-orange-50 flex items-center space-x-4 transition-colors group"
                        >
                          <div className="p-2 bg-gray-100 rounded group-hover:bg-white transition-colors">
                            <service.icon size={16} className="text-[#ec7211]" />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-bold">{service.label}</p>
                            <p className="text-[10px] text-gray-500 uppercase tracking-tight">{service.category}</p>
                          </div>
                          <ChevronRight size={14} className="text-gray-300 opacity-0 group-hover:opacity-100 transition-opacity" />
                        </button>
                    ))}
                  </div>
                </>
              ) : (
                <div className="p-8 text-center">
                   <Info size={32} className="mx-auto text-gray-200 mb-2" />
                   <p className="text-sm font-bold text-gray-400">No services match "{searchQuery}"</p>
                   <p className="text-[10px] text-gray-400 mt-1">Try searching for compute, storage, or security.</p>
                </div>
              )}
              {searchQuery.startsWith('i-') && (
                <button 
                  onClick={() => { onSearchRedirect(ServiceType.EC2); setShowSearchResults(false); setSearchQuery(''); }} 
                  className="w-full text-left px-3 py-3 hover:bg-blue-50 flex items-center space-x-4 transition-colors border-t border-gray-100 bg-gray-50/50"
                >
                    <div className="p-2 bg-blue-100 rounded">
                      <Cpu size={16} className="text-blue-600" />
                    </div>
                    <div>
                      <p className="text-sm font-mono font-bold text-blue-700">{searchQuery}</p>
                      <p className="text-[10px] text-blue-500 uppercase">Redirect to EC2 Instance Console</p>
                    </div>
                </button>
              )}
           </div>
        )}
      </div>

      <div className="flex items-center space-x-5 text-gray-300 text-sm shrink-0">
        <button 
          onClick={onOpenTerminal}
          className="p-1.5 rounded hover:bg-white/10 hover:text-white transition-all"
          title="Open CloudShell"
        >
          <TerminalIcon size={18} />
        </button>

        <div className="relative" ref={notifyRef}>
          <button 
            onClick={() => { closeAll(); setIsNotifyOpen(!isNotifyOpen); markAllRead(); }}
            className={`p-1.5 rounded transition-all relative ${isNotifyOpen ? 'bg-white/10 text-white' : 'hover:text-white'}`}
          >
            <Bell size={18} />
            {unreadCount > 0 && <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-[#232f3e] animate-pulse"></span>}
          </button>
          {isNotifyOpen && (
            <div className="absolute top-full right-0 mt-3 w-80 bg-white text-[#161e2d] shadow-2xl rounded-lg border border-gray-200 overflow-hidden z-[60] animate-in fade-in zoom-in-95 duration-200">
               <div className="px-4 py-3 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
                  <h3 className="font-bold text-sm">Recent Alerts</h3>
                  <button onClick={clearNotifications} className="text-[10px] font-bold text-gray-400 hover:text-red-500 flex items-center"><Trash2 size={10} className="mr-1"/>Clear all</button>
               </div>
               <div className="max-h-80 overflow-y-auto p-2 space-y-1">
                  {notifications.length === 0 ? (
                    <div className="py-12 flex flex-col items-center justify-center opacity-40">
                      <Inbox size={32} />
                      <p className="text-xs font-bold mt-2">No active alerts</p>
                    </div>
                  ) : (
                    notifications.map(n => (
                      <div key={n.id} className={`p-3 rounded border flex items-start space-x-3 transition-colors ${n.read ? 'bg-white border-gray-100 opacity-60' : 'bg-orange-50/50 border-[#ec7211]/20'}`}>
                         <div className={`w-8 h-8 rounded flex items-center justify-center shrink-0 ${
                           n.type === 'success' ? 'bg-green-100 text-green-600' :
                           n.type === 'warning' ? 'bg-orange-100 text-orange-600' : 'bg-blue-100 text-blue-600'
                         }`}>
                           {n.type === 'success' ? <Check size={16} /> : n.type === 'warning' ? <ShieldAlert size={16} /> : <Info size={16} />}
                         </div>
                         <div className="flex-1 min-w-0">
                            <p className="text-xs font-bold truncate">{n.title}</p>
                            <p className="text-[10px] text-gray-500 mt-0.5 line-clamp-2 leading-tight">{n.message}</p>
                            <p className="text-[9px] text-gray-400 mt-1 uppercase font-bold tracking-tight">{n.time}</p>
                         </div>
                      </div>
                    ))
                  )}
               </div>
            </div>
          )}
        </div>

        <div className="relative" ref={settingsRef}>
          <button onClick={() => { closeAll(); setIsSettingsOpen(!isSettingsOpen); }} className={`p-1.5 rounded transition-all ${isSettingsOpen ? 'bg-white/10 text-white' : 'hover:text-white'}`}>
            <SettingsIcon size={18} />
          </button>
          {isSettingsOpen && (
            <div className="absolute top-full right-0 mt-3 w-72 bg-white text-[#161e2d] shadow-2xl rounded-lg border border-gray-200 overflow-hidden z-[60] animate-in fade-in zoom-in-95 duration-200 text-left">
              <div className="px-4 py-3 bg-gray-50 border-b border-gray-200 flex items-center justify-between">
                <h3 className="font-bold text-sm text-gray-800">Console Settings</h3>
              </div>
              <div className="min-h-[220px] p-2">
                <div className="p-1 space-y-1">
                  {[
                    { id: 'display', label: 'Display Preferences', icon: Monitor },
                    { id: 'language', label: 'Language & Region', icon: Languages },
                    { id: 'shortcuts', label: 'Keyboard Shortcuts', icon: Keyboard },
                    { id: 'privacy', label: 'Privacy & Security', icon: Lock },
                  ].map((item) => (
                    <button key={item.id} className="w-full flex items-center justify-between px-3 py-3 hover:bg-gray-50 group transition-all rounded-sm text-left border border-transparent hover:border-gray-200">
                      <div className="flex items-center space-x-3">
                        <item.icon size={16} className="text-gray-500 group-hover:text-[#ec7211]" />
                        <p className="text-sm font-semibold text-gray-700">{item.label}</p>
                      </div>
                      <ChevronRight size={14} className="text-gray-300" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div className="relative" ref={userRef}>
          <div onClick={() => { closeAll(); setIsUserOpen(!isUserOpen); }} className={`flex items-center space-x-2 cursor-pointer border-l border-gray-600/50 pl-4 h-8 ${isUserOpen ? 'text-white' : 'hover:text-white'}`}>
            <div className="flex flex-col items-end leading-tight mr-1">
               <span className="font-bold text-[#ec7211] text-xs uppercase">{session.username}</span>
               <span className="text-[10px] text-gray-400 font-mono">ID: {session.accountId}</span>
            </div>
            <ChevronDown size={14} className={`transition-transform duration-200 ${isUserOpen ? 'rotate-180' : ''}`} />
          </div>
          {isUserOpen && (
            <div className="absolute top-full right-0 mt-3 w-64 bg-white text-[#161e2d] shadow-2xl rounded-lg border border-gray-200 overflow-hidden z-[60] p-4 animate-in fade-in slide-in-from-top-2 text-left">
               <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Account Info</p>
               <p className="text-sm font-bold text-gray-800">{session.email}</p>
               <div className="h-[1px] bg-gray-100 my-4"></div>
               <button onClick={onLogout} className="w-full text-left px-3 py-2.5 bg-red-50 text-red-600 text-xs font-bold rounded flex items-center space-x-2 hover:bg-red-100 transition-colors">
                  <LogOut size={16} /><span>Sign Out</span>
               </button>
            </div>
          )}
        </div>

        <div className="relative" ref={regionRef}>
          <div onClick={() => { closeAll(); setIsRegionOpen(!isRegionOpen); }} className="flex items-center space-x-1 cursor-pointer border-l border-gray-600/50 h-8 hover:text-white">
            <span className="text-[#ec7211] font-bold text-xs">{region}</span>
            <ChevronDown size={14} />
          </div>
          {isRegionOpen && (
            <div className="absolute top-full right-0 mt-3 w-64 bg-white text-[#161e2d] shadow-2xl rounded-lg border border-gray-200 z-[60] p-2 animate-in fade-in slide-in-from-top-2 text-left">
               {['Global (Core)', 'US East (N. Virginia)', 'Asia Pacific (Mumbai)'].map(r => (
                  <button key={r} onClick={() => { setRegion(r); setIsRegionOpen(false); addNotification('Region', `Region changed to ${r}`, 'info'); }} className="w-full text-left px-3 py-2 hover:bg-gray-50 text-xs font-bold text-gray-700 rounded transition-colors flex justify-between items-center">
                    <span>{r}</span>
                    {region === r && <Check size={14} className="text-orange-500" />}
                  </button>
               ))}
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};
