
import React, { useState } from 'react';
import { Film, Plus, RefreshCw, Layers, CheckCircle, Clock, Play, FileVideo, Cpu } from 'lucide-react';
import { useNotifications } from '../App';

export const ServiceTranscoder: React.FC = () => {
  const { addNotification } = useNotifications();
  const [jobs, setJobs] = useState([
    { id: 'mc-9821', source: 'movie_4k_hdr.mov', progress: 100, status: 'Complete', outputs: 6 },
    { id: 'mc-9822', source: 'episode_05_final.mxf', progress: 68, status: 'Processing', outputs: 4 },
  ]);

  const createJob = () => {
    const id = `mc-${Math.floor(Math.random() * 9000) + 1000}`;
    const newJob = { id, source: 'new_upload.mp4', progress: 0, status: 'Queued', outputs: 3 };
    setJobs([newJob, ...jobs]);
    addNotification('Transcoder', `Job ${id} submitted for encoding.`, 'info');
    
    setTimeout(() => {
       setJobs(prev => prev.map(j => j.id === id ? { ...j, status: 'Processing', progress: 15 } : j));
    }, 2000);
  };

  return (
    <div className="flex flex-col h-full bg-[#f8f9fa]">
      <div className="p-6 bg-white border-b flex justify-between items-center">
        <div>
           <h1 className="text-2xl font-bold flex items-center text-[#161e2d]">
              <Film className="mr-2 text-pink-600" /> Media Transcoder
           </h1>
           <p className="text-sm text-gray-500">Multiscreen ABR Encoding & Video Processing</p>
        </div>
        <button onClick={createJob} className="bg-pink-600 text-white px-6 py-2 rounded font-bold text-sm hover:bg-pink-700 shadow-md flex items-center space-x-2 transition-all">
           <Plus size={16} /><span>Create Transcoding Job</span>
        </button>
      </div>

      <div className="p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
           <div className="bg-white p-6 border rounded-lg shadow-sm">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Active Slots</p>
              <p className="text-2xl font-black">14 / 20</p>
              <div className="w-full h-1.5 bg-gray-100 rounded-full mt-3 overflow-hidden">
                 <div className="h-full bg-pink-500" style={{ width: '70%' }} />
              </div>
           </div>
           <div className="bg-white p-6 border rounded-lg shadow-sm">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Accelerated Encoding</p>
              <p className="text-2xl font-black text-green-600">Enabled</p>
              <p className="text-[10px] text-gray-400 mt-2 font-mono">AV1 & HEVC Hardware Support</p>
           </div>
           <div className="bg-white p-6 border rounded-lg shadow-sm">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Global Presets</p>
              <p className="text-2xl font-black">42</p>
              <p className="text-[10px] text-gray-400 mt-2 font-mono">Smart ABR v3.1</p>
           </div>
        </div>

        <div className="bg-white border rounded shadow-sm overflow-hidden">
           <div className="bg-gray-50 px-6 py-3 border-b flex items-center justify-between">
              <h3 className="text-xs font-bold text-gray-500 uppercase">Recent Encoding Jobs</h3>
              <RefreshCw size={14} className="text-gray-400 cursor-pointer" />
           </div>
           <table className="w-full text-left text-sm">
              <thead className="bg-gray-50/50 border-b text-[10px] font-bold text-gray-400 uppercase">
                 <tr>
                    <th className="p-4">Job ID</th>
                    <th className="p-4">Source Asset</th>
                    <th className="p-4">Progress</th>
                    <th className="p-4">Output Profiles</th>
                    <th className="p-4">Status</th>
                 </tr>
              </thead>
              <tbody className="divide-y">
                 {jobs.map(job => (
                    <tr key={job.id} className="hover:bg-gray-50 transition-colors">
                       <td className="p-4 font-mono text-xs">{job.id}</td>
                       <td className="p-4 font-bold flex items-center space-x-2">
                          <FileVideo size={16} className="text-gray-400" />
                          <span>{job.source}</span>
                       </td>
                       <td className="p-4 w-48">
                          <div className="flex items-center space-x-3">
                             <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                                <div className="h-full bg-pink-500 transition-all duration-1000" style={{ width: `${job.progress}%` }} />
                             </div>
                             <span className="text-[10px] font-bold w-6">{job.progress}%</span>
                          </div>
                       </td>
                       <td className="p-4">
                          <div className="flex -space-x-1">
                             {Array.from({ length: job.outputs }).map((_, i) => (
                                <div key={i} className="w-5 h-5 rounded-full bg-pink-100 border-2 border-white flex items-center justify-center text-[8px] font-bold text-pink-600">
                                   {i === 0 ? '4K' : i === 1 ? '10' : i === 2 ? '72' : 'SD'}
                                </div>
                             ))}
                          </div>
                       </td>
                       <td className="p-4">
                          <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${job.status === 'Complete' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700 animate-pulse'}`}>
                             {job.status}
                          </span>
                       </td>
                    </tr>
                 ))}
              </tbody>
           </table>
        </div>
      </div>
    </div>
  );
};
