
import React, { useState, useEffect } from 'react';
import { ShieldCheck, User as UserIcon, Lock, Key, Sparkles, Eye, EyeOff, Loader2, AlertCircle, ArrowRight, CheckCircle2, ShieldAlert, Mail, Smartphone, Fingerprint, LockIcon } from 'lucide-react';
import { UserRole, UserSession, ServiceType } from '../types';

interface AuthProps {
  onLogin: (session: UserSession) => void;
}

const ALL_PERMISSIONS = [
  ServiceType.EC2, ServiceType.S3, ServiceType.RDS, 
  ServiceType.VPC, ServiceType.LAMBDA, ServiceType.BILLING, ServiceType.SUPPORT,
  ServiceType.VIDEO_STREAMING, ServiceType.CDN, ServiceType.WAF, ServiceType.DYNAMODB,
  ServiceType.CLOUDWATCH_LOGS, ServiceType.TRANSCODER, ServiceType.AI_PERSONALIZATION, ServiceType.REALTIME_CHAT
];

export const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [isVerifying, setIsVerifying] = useState(false);
  const [role, setRole] = useState<UserRole>('user'); 
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [username, setUsername] = useState('');
  const [rootToken, setRootToken] = useState(''); 
  const [verificationCode, setVerificationCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [passwordStrength, setPasswordStrength] = useState(0);

  const DATABASE_KEY = 'streamx_cloud_database';

  const getDatabase = (): any[] => {
    const raw = localStorage.getItem(DATABASE_KEY);
    return raw ? JSON.parse(raw) : [];
  };

  useEffect(() => {
    const db = getDatabase();
    if (!db.some(u => u.email === '0')) {
      db.push({ 
        email: '0', password: '0', username: 'Root Admin', role: 'admin', 
        accountId: '001', permissions: ALL_PERMISSIONS 
      });
    }
    if (!db.some(u => u.email === '1')) {
      db.push({ 
        email: '1', password: '1', username: 'Demo User', role: 'user', 
        accountId: '100', permissions: [ServiceType.EC2, ServiceType.S3] 
      });
    }
    localStorage.setItem(DATABASE_KEY, JSON.stringify(db));
  }, []);

  const calculateStrength = (pass: string) => {
    let score = 0;
    if (pass.length > 6) score += 25;
    if (/[A-Z]/.test(pass)) score += 25;
    if (/[0-9]/.test(pass)) score += 25;
    if (/[^A-Za-z0-9]/.test(pass)) score += 25;
    setPasswordStrength(score);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);
    await new Promise(r => setTimeout(r, 1000));

    const db = getDatabase();
    const user = db.find((u: any) => u.email === email && u.password === password && u.role === role);
    
    if (user) {
      localStorage.setItem('cloud_console_session', JSON.stringify(user));
      onLogin(user);
    } else {
      setError(`Authentication failed for ${role === 'admin' ? 'Root Account' : 'IAM User'}. Check credentials.`);
      setIsLoading(false);
    }
  };

  const startSignupFlow = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    if (!isLogin && password !== confirmPassword) {
      setError('Passwords do not match. Verification failed.');
      setIsLoading(false);
      return;
    }

    if (role === 'admin' && !rootToken) {
       setError('Root Admin requires a Security Token (Simulated).');
       setIsLoading(false);
       return;
    }

    if (passwordStrength < 50 && role === 'user') {
      setError('Password security baseline not met.');
      setIsLoading(false);
      return;
    }

    if (passwordStrength < 75 && role === 'admin') {
      setError('Root passwords must meet military-grade entropy requirements.');
      setIsLoading(false);
      return;
    }

    const db = getDatabase();
    if (db.find(u => u.email === email)) {
      setError('Identifier already provisioned in the global registry.');
      setIsLoading(false);
      return;
    }

    await new Promise(r => setTimeout(r, 1200));
    setIsLoading(false);
    setIsVerifying(true);
  };

  const completeVerification = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    await new Promise(r => setTimeout(r, 1500));

    const db = getDatabase();
    const newUser = {
      email, 
      password, 
      username, 
      role, 
      accountId: role === 'admin' ? `00${db.length + 1}` : Math.floor(1000 + Math.random() * 9000).toString(),
      permissions: role === 'admin' ? ALL_PERMISSIONS : [ServiceType.EC2, ServiceType.S3]
    };
    
    db.push(newUser);
    localStorage.setItem(DATABASE_KEY, JSON.stringify(db));
    localStorage.setItem('cloud_console_session', JSON.stringify(newUser));
    onLogin(newUser);
  };

  if (isVerifying) {
    return (
      <div className="min-h-screen bg-[#080a11] flex flex-col items-center justify-center p-4 font-sans text-left">
        <div className="w-full max-w-md bg-[#111827] border border-white/10 rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-500">
          <div className={`h-1.5 w-full ${role === 'admin' ? 'bg-red-600' : 'bg-[#ec7211]'}`}></div>
          <div className="p-10">
            <div className="mb-8">
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-4 ${role === 'admin' ? 'bg-red-500/10 text-red-500' : 'bg-orange-500/10 text-orange-500'}`}>
                <Mail size={32} />
              </div>
              <h1 className="text-2xl font-black text-white">Identity Verification</h1>
              <p className="text-xs text-gray-500 mt-2 leading-relaxed">
                A simulated 6-digit access code was generated for <span className="text-white font-bold">{email}</span>.
              </p>
            </div>

            <form onSubmit={completeVerification} className="space-y-6">
              <div className="space-y-2">
                <input 
                  type="text" 
                  maxLength={6}
                  placeholder="0 0 0 0 0 0"
                  className="w-full text-center p-4 bg-black/40 border border-white/5 rounded-2xl outline-none focus:border-orange-500 text-white text-2xl font-black tracking-[0.5em]" 
                  value={verificationCode} onChange={(e) => setVerificationCode(e.target.value)} required 
                />
              </div>

              <button 
                type="submit" 
                className={`w-full py-4 rounded-2xl text-white font-black text-xs tracking-widest uppercase transition-all shadow-xl flex items-center justify-center space-x-2 active:scale-95 ${role === 'admin' ? 'bg-red-600 hover:bg-red-700 shadow-red-600/20' : 'bg-[#ec7211] hover:bg-orange-600 shadow-orange-500/20'}`}
              >
                {isLoading ? <Loader2 className="animate-spin" size={18} /> : <span>Establish Cloud Identity</span>}
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#080a11] flex flex-col items-center justify-center relative overflow-hidden font-sans p-4">
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-20">
        <div className={`absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full blur-[120px] ${role === 'admin' ? 'bg-red-600/20' : 'bg-orange-600/20'}`}></div>
        <div className={`absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full blur-[120px] ${role === 'admin' ? 'bg-red-900/10' : 'bg-blue-600/10'}`}></div>
      </div>

      <div className="relative z-10 w-full flex flex-col items-center">
        <div className="mb-10 flex flex-col items-center text-center">
          <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-4 shadow-2xl transition-all duration-700 ${role === 'admin' ? 'bg-red-600 shadow-red-600/30' : 'bg-[#ec7211] shadow-orange-500/30'}`}>
             {role === 'admin' ? <ShieldAlert className="text-white" size={32} /> : <ShieldCheck className="text-white" size={32} />}
          </div>
          <span className="text-5xl font-black tracking-tighter text-white">streamX</span>
          <p className="text-[10px] font-bold text-gray-500 uppercase tracking-[0.3em] mt-2">Cloud Management Hub</p>
        </div>

        <div className="w-full max-w-[460px] bg-[#111827]/90 backdrop-blur-2xl border border-white/10 rounded-3xl shadow-[0_32px_64px_rgba(0,0,0,0.5)] overflow-hidden transition-all duration-500">
          <div className={`h-1.5 w-full transition-all duration-700 ${role === 'admin' ? 'bg-red-600' : 'bg-[#ec7211]'}`}></div>
          
          <div className="p-8 md:p-10 text-left">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h1 className="text-2xl font-black text-white tracking-tight">{isLogin ? 'Sign in' : 'Create Account'}</h1>
                <p className="text-[10px] text-gray-500 mt-1 uppercase font-bold tracking-widest">{role === 'admin' ? 'Privileged Root Access' : 'Standard IAM Portal'}</p>
              </div>
              <div className={`px-3 py-1 rounded-full border text-[9px] font-black uppercase tracking-widest transition-colors ${role === 'admin' ? 'border-red-500 text-red-500 bg-red-500/5' : 'border-orange-500 text-orange-500 bg-orange-500/5'}`}>
                {role === 'admin' ? 'Root Mode' : 'Standard'}
              </div>
            </div>

            {error && (
              <div className="mb-6 p-4 bg-red-500/10 text-red-400 text-xs border border-red-500/20 rounded-xl flex items-start animate-in slide-in-from-top-2">
                <AlertCircle size={16} className="mr-3 mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={isLogin ? handleLogin : startSignupFlow} className="space-y-6">
              <div className="flex bg-black/40 p-1.5 rounded-2xl mb-8 border border-white/5">
                <button type="button" onClick={() => setRole('user')} className={`flex-1 py-3 text-[11px] font-black rounded-xl transition-all uppercase tracking-wider ${role === 'user' ? 'bg-[#1f2937] text-white shadow-lg border border-white/10' : 'text-gray-500 hover:text-gray-300'}`}>Cloud User</button>
                <button type="button" onClick={() => setRole('admin')} className={`flex-1 py-3 text-[11px] font-black rounded-xl transition-all uppercase tracking-wider ${role === 'admin' ? 'bg-red-600 text-white shadow-lg shadow-red-600/20' : 'text-gray-500 hover:text-gray-300'}`}>Root Admin</button>
              </div>
              
              {!isLogin && (
                <div className="space-y-2">
                  <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Account Holder Name</label>
                  <div className="relative">
                    <UserIcon size={18} className="absolute left-4 top-3.5 text-gray-600" />
                    <input type="text" placeholder="e.g. Administrator" className="w-full pl-12 p-3.5 bg-black/30 border border-white/5 rounded-2xl outline-none focus:border-orange-500 text-white text-sm" value={username} onChange={(e) => setUsername(e.target.value)} required />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Email Identifier</label>
                <div className="relative">
                  <Mail size={18} className="absolute left-4 top-3.5 text-gray-600" />
                  <input type="email" placeholder="user@streamx.global" className="w-full pl-12 p-3.5 bg-black/30 border border-white/5 rounded-2xl outline-none focus:border-orange-500 text-white text-sm" value={email} onChange={(e) => setEmail(e.target.value)} required />
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Password</label>
                <div className="relative">
                  <LockIcon size={18} className="absolute left-4 top-3.5 text-gray-600" />
                  <input 
                    type={showPassword ? "text" : "password"} 
                    placeholder="••••••••"
                    className="w-full pl-12 pr-12 p-3.5 bg-black/30 border border-white/5 rounded-2xl outline-none focus:border-orange-500 text-white text-sm" 
                    value={password} 
                    onChange={(e) => { setPassword(e.target.value); calculateStrength(e.target.value); }} 
                    required 
                  />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-3.5 text-gray-500 hover:text-white transition-colors">
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
                {!isLogin && password.length > 0 && (
                   <div className="px-1 pt-1">
                      <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                        <div className={`h-full transition-all duration-500 ${passwordStrength > 70 ? 'bg-green-500' : role === 'admin' ? 'bg-red-500' : 'bg-orange-500'}`} style={{ width: `${passwordStrength}%` }} />
                      </div>
                   </div>
                )}
              </div>

              {!isLogin && (
                <div className="space-y-2 animate-in slide-in-from-top-1">
                  <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest ml-1">Confirm Password</label>
                  <div className="relative">
                    <LockIcon size={18} className="absolute left-4 top-3.5 text-gray-600" />
                    <input 
                      type={showPassword ? "text" : "password"} 
                      placeholder="••••••••"
                      className={`w-full pl-12 p-3.5 bg-black/30 border rounded-2xl outline-none text-white text-sm transition-colors ${
                        password && confirmPassword 
                          ? password === confirmPassword 
                            ? 'border-green-500/50 focus:border-green-500' 
                            : 'border-red-500/50 focus:border-red-500'
                          : 'border-white/5 focus:border-orange-500'
                      }`}
                      value={confirmPassword} 
                      onChange={(e) => setConfirmPassword(e.target.value)} 
                      required 
                    />
                  </div>
                </div>
              )}

              {!isLogin && role === 'admin' && (
                <div className="space-y-2 animate-in slide-in-from-left-2">
                  <label className="block text-[10px] font-black text-red-500 uppercase tracking-widest ml-1 flex items-center">
                    <Fingerprint size={12} className="mr-1"/> Root Security Token
                  </label>
                  <input 
                    type="password" 
                    placeholder="Enter 16-digit hardware token" 
                    className="w-full p-3.5 bg-red-500/5 border border-red-500/20 rounded-2xl outline-none focus:border-red-500 text-white text-xs font-mono"
                    value={rootToken}
                    onChange={(e) => setRootToken(e.target.value)}
                    required
                  />
                  <p className="text-[9px] text-gray-600 italic">This is a simulated requirement for high-privilege accounts.</p>
                </div>
              )}

              <button 
                type="submit" 
                disabled={isLoading}
                className={`w-full py-4 rounded-2xl text-white font-black text-xs tracking-widest uppercase transition-all flex items-center justify-center space-x-2 active:scale-95 disabled:opacity-50 ${role === 'admin' ? 'bg-red-600 hover:bg-red-700 shadow-xl shadow-red-600/20' : 'bg-[#ec7211] hover:bg-orange-600 shadow-xl shadow-orange-500/20'}`}
              >
                {isLoading ? <Loader2 className="animate-spin" size={20} /> : <span>{isLogin ? 'Establish Session' : 'Continue to Verify'}</span>}
              </button>
            </form>

            <div className="mt-10 pt-6 border-t border-white/5 text-center">
              <button onClick={() => { setIsLogin(!isLogin); setError(null); setConfirmPassword(''); }} className="text-xs font-bold text-gray-500 hover:text-white transition-colors">
                {isLogin ? "Need a global identity? Sign Up" : "Existing identity? Return to Login"}
              </button>
            </div>
          </div>
        </div>

        <div className="mt-8 flex space-x-4">
           <button onClick={() => { setEmail('0'); setPassword('0'); setRole('admin'); }} className="px-4 py-2 bg-white/5 border border-white/5 rounded-xl text-[10px] font-bold text-gray-600 hover:bg-white/10 hover:text-white transition-all">Quick Root (0/0)</button>
           <button onClick={() => { setEmail('1'); setPassword('1'); setRole('user'); }} className="px-4 py-2 bg-white/5 border border-white/5 rounded-xl text-[10px] font-bold text-gray-600 hover:bg-white/10 hover:text-white transition-all">Quick IAM (1/1)</button>
        </div>
      </div>
    </div>
  );
};
