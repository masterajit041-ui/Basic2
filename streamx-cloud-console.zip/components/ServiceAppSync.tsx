
import React, { useState, useEffect } from 'react';
import { MessageSquareText, Radio, Users, Zap, Shield, Globe, Terminal, Code, Plus } from 'lucide-react';

export const ServiceAppSync: React.FC = () => {
  const [messages, setMessages] = useState<string[]>([]);

  useEffect(() => {
    const chatSamples = [
      "WOW! Incredible goal! 🔥",
      "Is it just me or the stream is super clear?",
      "Checking in from New York! Go StreamX!",
      "I love the new UI update!",
      "When is the next live event starting?",
      "That 4K resolution is insane. ✨",
    ];

    const interval = setInterval(() => {
      const msg = chatSamples[Math.floor(Math.random() * chatSamples.length)];
      setMessages(prev => [`[LIVE-CHAT] User_${Math.floor(Math.random()*900)+100}: ${msg}`, ...prev.slice(0, 5)]);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col h-full bg-[#f8f9fa] overflow-y-auto custom-scrollbar">
      <div className="p-6 bg-teal-800 text-white flex justify-between items-center">
        <div>
           <h1 className="text-2xl font-bold flex items-center">
              <MessageSquareText className="mr-2 text-teal-300" /> Real-time Interaction
           </h1>
           <p className="text-sm text-teal-100/60">Managed GraphQL Hub for Live Chat & Metadata Sync</p>
        </div>
        <div className="flex items-center space-x-2 text-xs bg-teal-900 px-3 py-1.5 rounded-full border border-teal-700">
           <Radio size={14} className="text-red-500 animate-pulse" />
           <span className="font-bold">Live API Status: OK</span>
        </div>
      </div>

      <div className="p-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
           <div className="bg-white border rounded-xl shadow-sm overflow-hidden">
              <div className="p-4 border-b flex justify-between items-center bg-gray-50">
                 <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest flex items-center">
                    <Terminal size={14} className="mr-2" /> Live GraphQL Stream
                 </h3>
                 <span className="text-[10px] text-gray-400">Total Connections: 124,902</span>
              </div>
              <div className="p-6 bg-[#0d1117] h-80 font-mono text-xs overflow-y-auto">
                 {messages.map((m, i) => (
                    <p key={i} className="text-teal-400 mb-1 opacity-90">{m}</p>
                 ))}
                 <p className="text-gray-600 animate-pulse mt-4">_ AWAITING SUBSCRIPTION DATA _</p>
              </div>
           </div>

           <div className="bg-white border rounded-xl p-6">
              <div className="flex justify-between items-center mb-6">
                 <h3 className="text-sm font-bold text-gray-800">Schema Definitions</h3>
                 <button className="text-xs font-bold text-teal-600 flex items-center"><Plus size={14} className="mr-1"/> Add Type</button>
              </div>
              <div className="space-y-4">
                 <div className="p-3 bg-gray-50 rounded border flex items-center justify-between group cursor-pointer hover:border-teal-300">
                    <div className="flex items-center space-x-3">
                       <Code size={16} className="text-gray-400 group-hover:text-teal-500" />
                       <span className="text-sm font-bold text-gray-700">LiveChat_Message</span>
                    </div>
                    <span className="text-[10px] text-gray-400">Subscription Enabled</span>
                 </div>
                 <div className="p-3 bg-gray-50 rounded border flex items-center justify-between group cursor-pointer hover:border-teal-300">
                    <div className="flex items-center space-x-3">
                       <Code size={16} className="text-gray-400 group-hover:text-teal-500" />
                       <span className="text-sm font-bold text-gray-700">User_Reaction_Event</span>
                    </div>
                    <span className="text-[10px] text-gray-400">Mutation Enabled</span>
                 </div>
              </div>
           </div>
        </div>

        <div className="space-y-6">
           <div className="bg-white border rounded-xl p-6 shadow-sm">
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-6 flex items-center">
                 <Globe size={14} className="mr-2 text-teal-500" /> Regional Ingest
              </h3>
              <div className="space-y-4">
                 {[
                   { name: 'Asia Pacific (Mumbai)', latency: '12ms', status: 'Online' },
                   { name: 'US East (N. Virginia)', latency: '45ms', status: 'Online' },
                   { name: 'Europe (Dublin)', latency: '38ms', status: 'Standby' },
                 ].map((r, i) => (
                    <div key={i} className="flex justify-between items-center text-sm">
                       <div className="flex flex-col">
                          <span className="font-bold text-gray-700">{r.name}</span>
                          <span className="text-[10px] text-gray-400">Latency: {r.latency}</span>
                       </div>
                       <span className={`w-2 h-2 rounded-full ${r.status === 'Online' ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]' : 'bg-gray-300'}`} />
                    </div>
                 ))}
              </div>
           </div>

           <div className="bg-teal-50 border border-teal-100 rounded-xl p-6">
              <div className="flex items-center space-x-2 mb-2">
                 <Shield className="text-teal-600" size={16} />
                 <h3 className="text-sm font-bold text-teal-900">Pub/Sub Security</h3>
              </div>
              <p className="text-xs text-teal-800 leading-relaxed">
                 IAM-based authentication is enforced for all chat mutations. Profanity filter is currently active on **LiveChat_Message** type.
              </p>
           </div>
        </div>
      </div>
    </div>
  );
};
