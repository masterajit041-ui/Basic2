import React, { useState } from 'react';
import { INITIAL_BUCKETS } from '../constants';
import { 
  Search, Plus, Trash2, RefreshCw, X, AlertTriangle, 
  ShieldAlert, Info, Database, Filter, ChevronRight, 
  Lock, Globe, Clock, MoreVertical, HardDrive
} from 'lucide-react';
import { Bucket } from '../types';
import { useNotifications } from '../App';

export const ServiceS3: React.FC = () => {
  const { addNotification } = useNotifications();
  const [buckets, setBuckets] = useState<Bucket[]>(INITIAL_BUCKETS);
  const [search, setSearch] = useState('');
  const [selectedBucketName, setSelectedBucketName] = useState<string | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [confirmInput, setConfirmInput] = useState('');

  const filteredBuckets = buckets.filter(b => 
    b.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleCreateBucket = () => {
    const name = `streamx-bucket-${Math.floor(Math.random() * 10000)}`;
    const newBucket: Bucket = {
      name,
      region: 'global-core',
      access: 'Private',
      created: new Date().toLocaleString()
    };
    setBuckets([newBucket, ...buckets]);
    addNotification('S3', `Bucket "${name}" created successfully.`, 'success');
  };

  const handleDeleteBucket = () => {
    if (selectedBucketName && confirmInput === selectedBucketName) {
      setBuckets(buckets.filter(b => b.name !== selectedBucketName));
      addNotification('S3', `Bucket "${selectedBucketName}" and all its contents have been permanently deleted.`, 'warning');
      setSelectedBucketName(null);
      setIsDeleteModalOpen(false);
      setConfirmInput('');
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#f8fafc] relative">
      {/* Premium Header */}
      <div className="px-8 py-6 bg-white border-b border-slate-200 sticky top-0 z-20">
        <div className="flex justify-between items-start">
            <div>
                <h1 className="text-2xl font-black text-slate-800 tracking-tight flex items-center">
                  <Database className="mr-3 text-orange-500" size={24} />
                  S3 Buckets
                </h1>
                <div className="flex items-center space-x-2 text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">
                   <span>Storage</span>
                   <ChevronRight size={10} />
                   <span>Global Namespace</span>
                </div>
            </div>
            <div className="flex items-center space-x-3">
              <button 
                onClick={() => { setBuckets(INITIAL_BUCKETS); addNotification('S3', 'Bucket list refreshed.', 'info'); }} 
                className="p-2.5 border border-slate-200 rounded-xl hover:bg-slate-50 text-slate-500 transition-all active:scale-95"
              >
                <RefreshCw size={18} />
              </button>
              <button 
                onClick={handleCreateBucket} 
                className="px-6 py-2.5 bg-[#ec7211] text-white rounded-xl font-black text-sm hover:bg-[#d66100] flex items-center space-x-2 shadow-lg shadow-orange-500/20 transition-all active:scale-95"
              >
                <Plus size={20} />
                <span>Create Bucket</span>
              </button>
            </div>
        </div>
        
        <div className="flex justify-between items-center mt-8">
            <div className="flex-1 max-w-xl relative group">
                <Search className="absolute left-4 top-3 text-slate-400 group-focus-within:text-orange-500 transition-colors" size={18} />
                <input 
                  type="text" 
                  placeholder="Find buckets by name..." 
                  className="w-full pl-12 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all text-sm font-medium" 
                  value={search} 
                  onChange={(e) => setSearch(e.target.value)} 
                />
            </div>
            <div className="flex space-x-3 ml-4">
                 <button 
                    disabled={!selectedBucketName}
                    onClick={() => { setConfirmInput(''); setIsDeleteModalOpen(true); }}
                    className="px-6 py-2.5 border border-red-200 text-red-600 rounded-xl text-sm font-black hover:bg-red-50 disabled:opacity-30 disabled:grayscale transition-all flex items-center space-x-2"
                >
                    <Trash2 size={18} />
                    <span>Delete</span>
                </button>
            </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="p-8 overflow-auto flex-1 custom-scrollbar">
         <div className="bg-white/70 backdrop-blur-md border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
             <table className="w-full text-left text-sm border-separate border-spacing-0">
                 <thead className="bg-slate-50/50 border-b border-slate-200 text-slate-400 uppercase text-[10px] font-black tracking-widest sticky top-0 z-10">
                     <tr>
                         <th className="p-4 w-12 text-center"></th>
                         <th className="p-4">Bucket Name</th>
                         <th className="p-4">Regional Logic</th>
                         <th className="p-4">Access Level</th>
                         <th className="p-4">Deployment Date</th>
                         <th className="p-4 w-10"></th>
                     </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-100">
                     {filteredBuckets.map((bucket) => (
                         <tr 
                            key={bucket.name} 
                            className={`hover:bg-orange-50/30 cursor-pointer transition-all ${selectedBucketName === bucket.name ? 'bg-orange-50/50' : ''}`}
                            onClick={() => setSelectedBucketName(bucket.name)}
                         >
                             <td className="p-4 text-center">
                               <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${selectedBucketName === bucket.name ? 'border-orange-500 bg-orange-500' : 'border-slate-300 bg-white'}`}>
                                  {selectedBucketName === bucket.name && <div className="w-2 h-2 bg-white rounded-full" />}
                               </div>
                             </td>
                             <td className="p-4">
                                <div className="flex items-center space-x-3">
                                   <div className="p-2 bg-slate-100 rounded-lg text-slate-500">
                                      <HardDrive size={16} />
                                   </div>
                                   <span className="font-black text-slate-700 hover:text-orange-600 transition-colors">{bucket.name}</span>
                                </div>
                             </td>
                             <td className="p-4 font-bold text-slate-500 flex items-center space-x-2">
                                <Globe size={14} className="text-slate-300" />
                                <span>{bucket.region}</span>
                             </td>
                             <td className="p-4">
                                 <span className={`px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest ${
                                   bucket.access === 'Public' ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'
                                 }`}>
                                   {bucket.access === 'Public' ? <ShieldAlert size={10} className="inline mr-1 mb-0.5" /> : <Lock size={10} className="inline mr-1 mb-0.5" />}
                                   {bucket.access}
                                 </span>
                             </td>
                             <td className="p-4 text-slate-400 font-mono text-xs flex items-center space-x-2">
                                <Clock size={14} className="text-slate-200" />
                                <span>{bucket.created}</span>
                             </td>
                             <td className="p-4">
                               <button className="p-1 hover:bg-slate-200 rounded-lg text-slate-300 transition-colors">
                                 <MoreVertical size={16} />
                               </button>
                             </td>
                         </tr>
                     ))}
                     {filteredBuckets.length === 0 && (
                        <tr>
                          <td colSpan={6} className="p-20 text-center text-slate-400">
                            <Search size={48} className="mx-auto mb-4 opacity-10" />
                            <p className="font-bold text-slate-500">No buckets matching your query</p>
                            <p className="text-xs mt-1">Try clearing filters or checking the global namespace.</p>
                          </td>
                        </tr>
                     )}
                 </tbody>
             </table>
         </div>
      </div>

      {/* AWS Style Destruction Verification Modal */}
      {isDeleteModalOpen && selectedBucketName && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center z-[300] px-4 animate-in fade-in duration-300">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden border border-red-100 animate-in zoom-in-95 duration-200">
            <div className="bg-red-50/80 p-6 border-b border-red-100 flex items-center justify-between">
              <h2 className="text-lg font-black text-red-700 flex items-center space-x-3">
                <AlertTriangle size={24} />
                <span>Delete Bucket</span>
              </h2>
              <button 
                onClick={() => setIsDeleteModalOpen(false)}
                className="p-2 hover:bg-red-100 rounded-full text-red-300 transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="p-8 space-y-6">
               <div className="bg-red-50 p-5 rounded-2xl border border-red-100 flex items-start space-x-4">
                  <ShieldAlert size={24} className="text-red-600 mt-0.5 shrink-0" />
                  <div className="text-sm text-red-900 leading-relaxed">
                    <p className="font-black mb-1 uppercase tracking-tight text-red-700">Permanent Data Purge</p>
                    <p className="font-medium">You are about to delete the bucket <strong>{selectedBucketName}</strong>. This will instantly and <strong>irreversibly</strong> destroy all stored objects, metadata, and versioning history.</p>
                  </div>
               </div>

               <div className="space-y-4">
                 <div className="text-sm text-slate-600 font-medium">
                   To confirm deletion, type the name of the bucket in the field below:
                   <div className="mt-2 p-3 bg-slate-50 border border-slate-200 rounded-xl font-mono text-center text-red-600 font-black tracking-tight select-none">
                     {selectedBucketName}
                   </div>
                 </div>
                 
                 <div className="relative">
                    <input 
                      type="text"
                      className={`w-full px-5 py-3 border rounded-2xl text-sm font-bold outline-none transition-all ${
                        confirmInput === selectedBucketName 
                          ? 'border-emerald-500 ring-4 ring-emerald-500/10 bg-emerald-50/30' 
                          : 'border-slate-200 focus:border-red-500 focus:ring-4 focus:ring-red-500/10'
                      }`}
                      placeholder="Type bucket name here..."
                      value={confirmInput}
                      onChange={(e) => setConfirmInput(e.target.value)}
                      autoFocus
                      onPaste={(e) => e.preventDefault()}
                    />
                    {confirmInput === selectedBucketName && (
                      <div className="absolute right-4 top-3 text-emerald-500 animate-in zoom-in duration-300">
                        <Info size={20} />
                      </div>
                    )}
                 </div>
               </div>
            </div>

            <div className="bg-slate-50 px-8 py-6 border-t border-slate-100 flex justify-end space-x-4">
              <button 
                onClick={() => setIsDeleteModalOpen(false)} 
                className="px-6 py-2.5 text-sm font-black text-slate-500 hover:text-slate-800 transition-all uppercase tracking-widest"
              >
                Abort
              </button>
              <button 
                disabled={confirmInput !== selectedBucketName}
                onClick={handleDeleteBucket}
                className={`px-10 py-2.5 text-sm font-black rounded-xl shadow-lg transition-all uppercase tracking-widest ${
                  confirmInput === selectedBucketName 
                    ? 'bg-red-600 text-white hover:bg-red-700 shadow-red-500/20 active:scale-95' 
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed opacity-50'
                }`}
              >
                Delete Bucket Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};