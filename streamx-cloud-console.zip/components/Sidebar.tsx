
import React from 'react';
import { ServiceType, UserRole } from '../types';
// Added missing Network icon to imports from lucide-react
import { 
  Home, Box, Database, HardDrive, Globe, ChevronDown, ChevronRight,
  Users, Zap, CreditCard, HelpCircle, Lock, PlaySquare, Share2,
  DoorOpen, ShieldAlert, ShieldX, Terminal, TableProperties,
  Film, BrainCircuit, MessageSquareText, LayoutGrid, Network
} from 'lucide-react';

interface SidebarProps {
  currentView: ServiceType;
  onChangeView: (view: ServiceType) => void;
  isOpen: boolean;
  toggleSidebar: () => void;
  role: UserRole;
  userPermissions: string[];
}

const NavItem = ({ 
  icon: Icon, 
  label, 
  active, 
  onClick, 
  expanded = true,
  colorClass = "",
  locked = false
}: { 
  icon: any, 
  label: string, 
  active: boolean, 
  onClick: () => void,
  expanded: boolean,
  colorClass?: string,
  locked?: boolean
}) => (
  <div 
    onClick={onClick}
    className={`
      flex items-center justify-between px-4 py-3 cursor-pointer text-sm transition-all duration-200 group relative
      ${active ? 'bg-gradient-to-r from-[#ec7211] to-[#ff9900] text-white font-bold shadow-[0_8px_16px_rgba(236,114,17,0.2)]' : 'text-slate-400 hover:text-white hover:bg-white/5'}
      ${active ? 'rounded-r-xl mr-2' : ''}
    `}
    title={!expanded ? label : ''}
  >
    <div className="flex items-center space-x-4">
      <div className="relative">
        <Icon size={20} className={active ? 'drop-shadow-sm' : colorClass} />
        {locked && !active && (
           <div className="absolute -top-1.5 -right-1.5 bg-[#1b2531] rounded-full p-0.5 border border-slate-600 group-hover:bg-orange-600 transition-colors shadow-sm">
              <Lock size={8} className="text-slate-400 group-hover:text-white" />
           </div>
        )}
      </div>
      {expanded && <span className="tracking-wide whitespace-nowrap overflow-hidden transition-all duration-300">{label}</span>}
    </div>
    {expanded && active && <ChevronRight size={14} className="text-white/50" />}
  </div>
);

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onChangeView, isOpen, toggleSidebar, role, userPermissions }) => {
  const isAdmin = role === 'admin';
  const hasPerm = (type: ServiceType) => isAdmin || userPermissions.includes(type);

  return (
    <aside className={`bg-[#111827] h-[calc(100vh-52px)] fixed top-[52px] left-0 z-40 flex flex-col border-r border-white/5 transition-all duration-300 ease-in-out ${isOpen ? 'w-64' : 'w-16'}`}>
      <div className="flex justify-center md:justify-end p-3 border-b border-white/5">
        <button 
          onClick={toggleSidebar} 
          className="p-2 rounded-xl bg-white/5 text-slate-500 hover:text-white hover:bg-white/10 transition-all group"
        >
          {isOpen ? <LayoutGrid size={18} className="group-hover:rotate-90 transition-transform" /> : <ChevronRight size={18} />}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar pt-4 pb-10">
        <NavItem icon={Home} label="Console Home" active={currentView === ServiceType.DASHBOARD} onClick={() => onChangeView(ServiceType.DASHBOARD)} expanded={isOpen} />

        {isOpen && (
          <div className="px-5 py-6 text-[10px] font-black text-slate-600 uppercase tracking-[0.25em] flex items-center space-x-3">
             <span className="whitespace-nowrap">Core Fabric</span>
             <div className="h-px flex-1 bg-white/5"></div>
          </div>
        )}

        <div className="space-y-1">
            <NavItem icon={Box} label="EC2 Nodes" active={currentView === ServiceType.EC2} onClick={() => onChangeView(ServiceType.EC2)} expanded={isOpen} colorClass="text-blue-400/70" locked={!hasPerm(ServiceType.EC2)} />
            <NavItem icon={HardDrive} label="S3 Buckets" active={currentView === ServiceType.S3} onClick={() => onChangeView(ServiceType.S3)} expanded={isOpen} colorClass="text-orange-400/70" locked={!hasPerm(ServiceType.S3)} />
            <NavItem icon={Network} label="VPC Networks" active={currentView === ServiceType.VPC} onClick={() => onChangeView(ServiceType.VPC)} expanded={isOpen} colorClass="text-violet-400/70" locked={!hasPerm(ServiceType.VPC)} />
        </div>

        {isOpen && (
          <div className="px-5 py-6 text-[10px] font-black text-slate-600 uppercase tracking-[0.25em] flex items-center space-x-3">
             <span className="whitespace-nowrap">Content Stack</span>
             <div className="h-px flex-1 bg-white/5"></div>
          </div>
        )}

        <div className="space-y-1">
            <NavItem icon={PlaySquare} label="Video Delivery" active={currentView === ServiceType.VIDEO_STREAMING} onClick={() => onChangeView(ServiceType.VIDEO_STREAMING)} expanded={isOpen} colorClass="text-red-400/70" locked={!hasPerm(ServiceType.VIDEO_STREAMING)} />
            <NavItem icon={Film} label="Media Transcoder" active={currentView === ServiceType.TRANSCODER} onClick={() => onChangeView(ServiceType.TRANSCODER)} expanded={isOpen} colorClass="text-pink-400/70" locked={!hasPerm(ServiceType.TRANSCODER)} />
            <NavItem icon={Share2} label="CDN / Edges" active={currentView === ServiceType.CDN} onClick={() => onChangeView(ServiceType.CDN)} expanded={isOpen} colorClass="text-sky-400/70" locked={!hasPerm(ServiceType.CDN)} />
        </div>

        {isOpen && (
          <div className="px-5 py-6 text-[10px] font-black text-slate-600 uppercase tracking-[0.25em] flex items-center space-x-3">
             <span className="whitespace-nowrap">Intelligence</span>
             <div className="h-px flex-1 bg-white/5"></div>
          </div>
        )}

        <div className="space-y-1">
            <NavItem icon={BrainCircuit} label="AI Personalize" active={currentView === ServiceType.AI_PERSONALIZATION} onClick={() => onChangeView(ServiceType.AI_PERSONALIZATION)} expanded={isOpen} colorClass="text-purple-400/70" locked={!hasPerm(ServiceType.AI_PERSONALIZATION)} />
            <NavItem icon={MessageSquareText} label="GraphQL Interaction" active={currentView === ServiceType.REALTIME_CHAT} onClick={() => onChangeView(ServiceType.REALTIME_CHAT)} expanded={isOpen} colorClass="text-teal-400/70" locked={!hasPerm(ServiceType.REALTIME_CHAT)} />
        </div>

        {isOpen && (
          <div className="px-5 py-6 text-[10px] font-black text-slate-600 uppercase tracking-[0.25em] flex items-center space-x-3">
             <span className="whitespace-nowrap">Management</span>
             <div className="h-px flex-1 bg-white/5"></div>
          </div>
        )}

        <div className="space-y-1 mb-6">
            <NavItem icon={ShieldX} label="WAF Guard" active={currentView === ServiceType.WAF} onClick={() => onChangeView(ServiceType.WAF)} expanded={isOpen} colorClass="text-amber-400/70" locked={!hasPerm(ServiceType.WAF)} />
            <NavItem icon={Terminal} label="System Logs" active={currentView === ServiceType.CLOUDWATCH_LOGS} onClick={() => onChangeView(ServiceType.CLOUDWATCH_LOGS)} expanded={isOpen} colorClass="text-emerald-400/70" locked={!hasPerm(ServiceType.CLOUDWATCH_LOGS)} />
        </div>

        <div className="mt-auto pt-6 border-t border-white/5 space-y-1">
          <NavItem icon={CreditCard} label="Billing Console" active={currentView === ServiceType.BILLING} onClick={() => onChangeView(ServiceType.BILLING)} expanded={isOpen} />
          <NavItem icon={HelpCircle} label="Documentation" active={currentView === ServiceType.SUPPORT} onClick={() => onChangeView(ServiceType.SUPPORT)} expanded={isOpen} />
        </div>
      </div>
    </aside>
  );
};
