
import React, { useState } from 'react';
import { TableProperties, Plus, Search, RefreshCw, X, ChevronRight, Activity, Database, DatabaseZap } from 'lucide-react';
import { useNotifications } from '../App';

export const ServiceDynamoDB: React.FC = () => {
  const { addNotification } = useNotifications();
  const [tables] = useState([
    { name: 'user-watch-history', partitionKey: 'user_id (S)', sortKey: 'timestamp (N)', status: 'Active', count: '1.2M' },
    { name: 'video-metadata', partitionKey: 'video_id (S)', sortKey: '-', status: 'Active', count: '45.1k' },
    { name: 'live-viewer-sessions', partitionKey: 'session_id (S)', sortKey: '-', status: 'Active', count: '12,901' },
  ]);

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="p-6 border-b border-gray-200 flex justify-between items-center">
        <div>
           <h1 className="text-2xl font-bold text-[#161e2d] flex items-center">
              <TableProperties className="mr-2 text-purple-600" /> DynamoDB Tables
           </h1>
           <p className="text-sm text-gray-500">NoSQL Database for High-Scale Metadata</p>
        </div>
        <button className="bg-[#ec7211] text-white px-6 py-2 rounded font-bold text-sm shadow-md hover:bg-orange-600">Create table</button>
      </div>

      <div className="p-8 space-y-6 overflow-y-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           <div className="bg-purple-50 border border-purple-100 p-6 rounded-lg flex items-start space-x-4">
              <DatabaseZap className="text-purple-600 mt-1" size={24} />
              <div>
                 <h3 className="font-bold text-purple-900">Provisioned Capacity</h3>
                 <p className="text-xs text-purple-700 mt-1">Your tables are currently configured with <strong>On-Demand</strong> capacity. Ideal for fluctuating streaming traffic patterns.</p>
              </div>
           </div>
           <div className="bg-blue-50 border border-blue-100 p-6 rounded-lg flex items-start space-x-4">
              <Activity className="text-blue-600 mt-1" size={24} />
              <div>
                 <h3 className="font-bold text-blue-900">Global Replication</h3>
                 <p className="text-xs text-blue-700 mt-1">Multi-region replication is active for <strong>user-watch-history</strong>. Sub-10ms latency globally.</p>
              </div>
           </div>
        </div>

        <div className="border border-gray-200 rounded-lg overflow-hidden shadow-sm">
           <table className="w-full text-left text-sm">
              <thead className="bg-gray-50 border-b font-bold text-[10px] uppercase text-gray-500">
                 <tr>
                    <th className="p-4">Table Name</th>
                    <th className="p-4">Partition Key</th>
                    <th className="p-4">Status</th>
                    <th className="p-4">Item Count</th>
                    <th className="p-4">Action</th>
                 </tr>
              </thead>
              <tbody className="divide-y">
                 {tables.map(table => (
                    <tr key={table.name} className="hover:bg-gray-50 cursor-pointer group">
                       <td className="p-4 font-bold text-[#0073bb] group-hover:underline">{table.name}</td>
                       <td className="p-4 font-mono text-xs">{table.partitionKey}</td>
                       <td className="p-4">
                          <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase">{table.status}</span>
                       </td>
                       <td className="p-4 text-gray-500 font-bold">{table.count}</td>
                       <td className="p-4 text-center">
                          <ChevronRight size={16} className="text-gray-300 group-hover:text-orange-500" />
                       </td>
                    </tr>
                 ))}
              </tbody>
           </table>
        </div>
      </div>
    </div>
  );
};
