
import React, { useState } from 'react';
import { INITIAL_VPCS } from '../constants';
import { Network, Search, Plus, Trash2, RefreshCw, Globe, Shield, Server, X, Info } from 'lucide-react';
import { VPCNetwork } from '../types';
import { useNotifications } from '../App';

export const ServiceVPC: React.FC = () => {
  const { addNotification } = useNotifications();
  const [vpcs, setVpcs] = useState<VPCNetwork[]>(INITIAL_VPCS);
  const [search, setSearch] = useState('');
  const [selectedVpc, setSelectedVpc] = useState<string | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const filteredVpcs = vpcs.filter(v => 
    v.name.toLowerCase().includes(search.toLowerCase()) || 
    v.id.toLowerCase().includes(search.toLowerCase())
  );

  const handleCreateVPC = () => {
    const newId = `vpc-${Math.random().toString(36).substr(2, 9)}`;
    const now = new Date().toLocaleString();
    const newVpc: VPCNetwork = {
      id: newId,
      name: `custom-vpc-${vpcs.length + 1}`,
      cidr: '10.0.0.0/16',
      state: 'available',
      tenancy: 'default',
      createdAt: now
    };
    setVpcs([newVpc, ...vpcs]);
    setIsCreateModalOpen(false);
    addNotification('VPC', `VPC "${newVpc.name}" created at ${now}.`, 'success');
  };

  const handleDeleteVPC = () => {
    if (selectedVpc) {
      const vpcName = vpcs.find(v => v.id === selectedVpc)?.name;
      setVpcs(vpcs.filter(v => v.id !== selectedVpc));
      addNotification('VPC', `VPC "${vpcName}" deleted.`, 'warning');
      setSelectedVpc(null);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center bg-white sticky top-0 z-20">
        <div>
          <h1 className="text-2xl font-bold text-[#161e2d]">Your VPCs</h1>
          <p className="text-sm text-gray-500">VPC > Your VPCs</p>
        </div>
        <div className="flex space-x-3">
          <button 
            disabled={!selectedVpc}
            onClick={handleDeleteVPC}
            className="px-4 py-1.5 border border-red-200 text-red-600 rounded text-sm font-bold hover:bg-red-50 disabled:opacity-50"
          >
            Delete VPC
          </button>
          <button 
            onClick={() => setIsCreateModalOpen(true)}
            className="px-4 py-1.5 bg-[#ec7211] text-white rounded text-sm font-bold hover:bg-[#d66100] shadow-sm flex items-center"
          >
            <Plus size={16} className="mr-1" /> Create VPC
          </button>
        </div>
      </div>

      <div className="p-4 bg-white border-b border-gray-200 flex items-center space-x-4">
        <div className="relative flex-1 max-w-xl">
          <Search className="absolute left-3 top-2 text-gray-400" size={16} />
          <input 
            type="text" 
            placeholder="Search VPCs" 
            className="w-full pl-9 pr-4 py-1.5 border border-gray-300 rounded text-sm outline-none focus:ring-1 focus:ring-[#ec7211]"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <button onClick={() => { setVpcs(INITIAL_VPCS); addNotification('VPC', 'VPC list refreshed.', 'info'); }} className="p-2 border border-gray-300 rounded text-gray-500 hover:bg-gray-50"><RefreshCw size={18} /></button>
      </div>

      <div className="flex-1 overflow-auto p-4 bg-[#f8f9fa]">
        <div className="border border-gray-300 rounded overflow-hidden bg-white shadow-sm">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 border-b border-gray-200 text-gray-600 uppercase text-[10px] font-bold">
              <tr>
                <th className="p-3 w-10 text-center"></th>
                <th className="p-3">Name</th>
                <th className="p-3">VPC ID</th>
                <th className="p-3">State</th>
                <th className="p-3">IPv4 CIDR</th>
                <th className="p-3">Tenancy</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredVpcs.map((vpc) => (
                <tr 
                  key={vpc.id} 
                  className={`hover:bg-blue-50 cursor-pointer ${selectedVpc === vpc.id ? 'bg-blue-50' : ''}`}
                  onClick={() => setSelectedVpc(vpc.id)}
                >
                  <td className="p-3 text-center"><input type="radio" checked={selectedVpc === vpc.id} readOnly className="text-[#ec7211]" /></td>
                  <td className="p-3 font-bold text-[#0073bb]">{vpc.name}</td>
                  <td className="p-3 font-mono text-xs">{vpc.id}</td>
                  <td className="p-3">
                    <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase">{vpc.state}</span>
                  </td>
                  <td className="p-3 text-gray-600">{vpc.cidr}</td>
                  <td className="p-3 capitalize text-gray-500">{vpc.tenancy}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedVpc && (
        <div className="h-64 border-t border-gray-300 bg-white p-6 animate-in slide-in-from-bottom duration-300 overflow-y-auto">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-2">
              <h3 className="text-lg font-bold text-gray-800">VPC: {vpcs.find(v => v.id === selectedVpc)?.name}</h3>
              <span className="text-xs text-gray-400 font-mono">({selectedVpc})</span>
            </div>
            <div className="text-[10px] text-gray-400 font-bold uppercase">Created At: {vpcs.find(v => v.id === selectedVpc)?.createdAt || 'Legacy'}</div>
          </div>
          <div className="grid grid-cols-4 gap-6">
            <div className="space-y-4">
              <div className="flex flex-col"><span className="text-[10px] font-bold text-gray-400 uppercase">Subnets</span><span className="text-sm font-bold text-[#0073bb] hover:underline cursor-pointer">3 subnets</span></div>
              <div className="flex flex-col"><span className="text-[10px] font-bold text-gray-400 uppercase">Route Tables</span><span className="text-sm font-bold text-[#0073bb] hover:underline cursor-pointer">1 route table</span></div>
            </div>
            <div className="space-y-4">
              <div className="flex flex-col"><span className="text-[10px] font-bold text-gray-400 uppercase">Internet Gateways</span><span className="text-sm font-bold text-[#0073bb] hover:underline cursor-pointer">1 gateway</span></div>
              <div className="flex flex-col"><span className="text-[10px] font-bold text-gray-400 uppercase">DHCP Option Sets</span><span className="text-sm text-gray-700">dopt-01234567</span></div>
            </div>
            <div className="col-span-2 bg-gray-50 border rounded p-4 flex items-start space-x-3">
               <Shield className="text-blue-600 mt-1" size={20} />
               <div className="space-y-1">
                  <p className="text-xs font-bold text-gray-800">Security Best Practices</p>
                  <p className="text-[10px] text-gray-500 leading-relaxed">This VPC uses standard Flow Logs for monitoring. Consider enabling Network ACLs for additional layer of security between subnets.</p>
               </div>
            </div>
          </div>
        </div>
      )}

      {isCreateModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[200] px-4">
          <div className="bg-white rounded shadow-2xl w-full max-w-lg overflow-hidden border border-gray-300">
             <div className="bg-gray-50 p-4 border-b border-gray-200 flex justify-between items-center font-bold">
                <h2>Create VPC</h2>
                <button onClick={() => setIsCreateModalOpen(false)}><X size={20} /></button>
             </div>
             <div className="p-6 space-y-4">
                <div>
                   <label className="block text-xs font-bold text-gray-700 mb-1 uppercase">Name tag</label>
                   <input type="text" placeholder="my-secure-vpc" className="w-full px-3 py-2 border rounded text-sm outline-none focus:ring-1 focus:ring-[#ec7211]" />
                </div>
                <div>
                   <label className="block text-xs font-bold text-gray-700 mb-1 uppercase">IPv4 CIDR block</label>
                   <input type="text" defaultValue="10.0.0.0/16" className="w-full px-3 py-2 border rounded text-sm outline-none focus:ring-1 focus:ring-[#ec7211]" />
                </div>
                <div className="bg-blue-50 border-l-4 border-blue-600 p-4 flex items-start space-x-3">
                   <Info size={18} className="text-blue-600 mt-0.5" />
                   <p className="text-[10px] text-blue-900 leading-tight font-medium">Standard VPC creation allocates a default route table and main network ACL. Subnets must be created manually after VPC allocation.</p>
                </div>
             </div>
             <div className="bg-gray-50 px-6 py-4 border-t border-gray-200 flex justify-end space-x-3">
                <button onClick={() => setIsCreateModalOpen(false)} className="px-6 py-2 text-sm font-bold text-gray-700 bg-white border border-gray-300 rounded">Cancel</button>
                <button onClick={handleCreateVPC} className="px-8 py-2 text-sm font-bold bg-[#ec7211] text-white rounded shadow hover:bg-[#d66100]">Create VPC</button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};
