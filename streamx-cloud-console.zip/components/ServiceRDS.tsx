
import React, { useState } from 'react';
import { INITIAL_DATABASES } from '../constants';
import { Search, Plus, Trash2, RefreshCw, Database, Server, Globe, ExternalLink, X, AlertCircle } from 'lucide-react';
import { RDSDatabase } from '../types';
import { useNotifications } from '../App';

export const ServiceRDS: React.FC = () => {
  const { addNotification } = useNotifications();
  const [databases, setDatabases] = useState<RDSDatabase[]>(INITIAL_DATABASES);
  const [search, setSearch] = useState('');
  const [selectedDb, setSelectedDb] = useState<string | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const filteredDbs = databases.filter(db => 
    db.name.toLowerCase().includes(search.toLowerCase()) || 
    db.id.toLowerCase().includes(search.toLowerCase())
  );

  const handleCreateDB = () => {
    const newId = `db-${Math.random().toString(36).substr(2, 9)}`;
    const now = new Date().toLocaleString();
    const newDB: RDSDatabase = {
      id: newId,
      name: `db-instance-${databases.length + 1}`,
      engine: 'MySQL',
      status: 'creating',
      size: 'db.t3.micro',
      endpoint: '-',
      az: 'global-1a',
      createdAt: now
    };
    
    setDatabases([newDB, ...databases]);
    setIsCreateModalOpen(false);
    addNotification('RDS', `Database "${newDB.name}" initialization started at ${now}.`, "info");
    
    setTimeout(() => {
      setDatabases(prev => prev.map(db => 
        db.id === newId ? { ...db, status: 'available', endpoint: `${db.name}.streamx-cloud.net` } : db
      ));
      addNotification('RDS', `Database "${newDB.name}" is now AVAILABLE.`, "success");
    }, 4000);
  };

  const handleDeleteDB = () => {
    if (selectedDb) {
      const dbName = databases.find(d => d.id === selectedDb)?.name;
      setDatabases(databases.filter(db => db.id !== selectedDb));
      setSelectedDb(null);
      addNotification('RDS', `Database "${dbName}" has been deleted.`, "warning");
    }
  };

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center bg-white sticky top-0 z-20">
        <div>
          <h1 className="text-2xl font-bold text-[#161e2d]">Databases</h1>
          <p className="text-sm text-gray-500">RDS > Databases</p>
        </div>
        <div className="flex space-x-3">
          <button 
            disabled={!selectedDb}
            onClick={handleDeleteDB}
            className="px-4 py-1.5 border border-red-200 text-red-600 rounded text-sm font-bold hover:bg-red-50 disabled:opacity-50"
          >
            Delete
          </button>
          <button 
            onClick={() => setIsCreateModalOpen(true)}
            className="px-4 py-1.5 bg-[#ec7211] text-white rounded text-sm font-bold hover:bg-[#d66100] shadow-sm flex items-center"
          >
            <Plus size={16} className="mr-1" /> Create database
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col">
        <div className="bg-white p-4 border-b border-gray-200 flex items-center space-x-4">
          <div className="relative flex-1 max-w-xl">
            <Search className="absolute left-3 top-2.5 text-gray-400" size={16} />
            <input 
              type="text" 
              placeholder="Filter databases" 
              className="w-full pl-9 pr-4 py-1.5 border border-gray-300 rounded text-sm focus:ring-1 focus:ring-[#ec7211] outline-none"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <button onClick={() => { setDatabases(INITIAL_DATABASES); addNotification('RDS', "Database list synchronized.", "info"); }} className="p-2 text-gray-600 hover:bg-gray-100 rounded border border-gray-300">
            <RefreshCw size={18} />
          </button>
        </div>

        <div className="p-4 overflow-auto bg-[#f8f9fa] flex-1">
          <div className="border border-gray-300 rounded overflow-hidden bg-white shadow-sm">
            <table className="w-full text-left text-sm">
              <thead className="bg-gray-50 border-b border-gray-200 text-gray-600 uppercase text-[10px] font-bold">
                <tr>
                  <th className="p-3 w-10"></th>
                  <th className="p-3">DB identifier</th>
                  <th className="p-3">Engine</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Size</th>
                  <th className="p-3">Endpoint</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredDbs.map((db) => (
                  <tr 
                    key={db.id} 
                    className={`hover:bg-blue-50 cursor-pointer ${selectedDb === db.id ? 'bg-blue-50' : ''}`}
                    onClick={() => setSelectedDb(db.id)}
                  >
                    <td className="p-3 text-center">
                      <input type="radio" checked={selectedDb === db.id} readOnly />
                    </td>
                    <td className="p-3 font-bold text-[#0073bb] hover:underline">{db.name}</td>
                    <td className="p-3">{db.engine}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        db.status === 'available' ? 'bg-green-100 text-green-700' : 
                        db.status === 'creating' ? 'bg-yellow-100 text-yellow-700 animate-pulse' : 'bg-gray-100 text-gray-600'
                      }`}>
                        {db.status}
                      </span>
                    </td>
                    <td className="p-3 font-mono text-xs">{db.size}</td>
                    <td className="p-3 font-mono text-xs text-gray-500">{db.endpoint}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {selectedDb && (
        <div className="h-48 border-t border-gray-300 bg-white p-6 flex space-x-12 animate-in slide-in-from-bottom duration-300">
          <div>
            <h4 className="text-xs font-bold text-gray-400 uppercase mb-4">Connectivity & Security</h4>
            <div className="space-y-2">
              <div className="flex flex-col">
                <span className="text-xs text-gray-500">Endpoint</span>
                <span className="text-sm font-bold text-[#0073bb]">{databases.find(d => d.id === selectedDb)?.endpoint}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs text-gray-500">Creation Time</span>
                <span className="text-sm font-bold">{databases.find(d => d.id === selectedDb)?.createdAt || 'Legacy'}</span>
              </div>
            </div>
          </div>
          <div>
            <h4 className="text-xs font-bold text-gray-400 uppercase mb-4">Configuration</h4>
            <div className="grid grid-cols-2 gap-x-8 gap-y-2">
              <div className="flex flex-col">
                <span className="text-xs text-gray-500">Engine version</span>
                <span className="text-sm">8.0.35</span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs text-gray-500">License model</span>
                <span className="text-sm">General Public License</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {isCreateModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[110] px-4">
          <div className="bg-white rounded shadow-2xl w-full max-w-xl overflow-hidden border border-gray-300">
            <div className="bg-gray-50 p-4 border-b border-gray-200 flex justify-between items-center">
              <h2 className="text-lg font-bold">Create database</h2>
              <button onClick={() => setIsCreateModalOpen(false)}><X size={20} /></button>
            </div>
            <div className="p-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">Engine options</label>
                  <div className="grid grid-cols-3 gap-3">
                    {['MySQL', 'PostgreSQL', 'Aurora'].map(engine => (
                      <div key={engine} className="p-3 border rounded cursor-pointer hover:border-[#ec7211] border-gray-200 bg-gray-50 flex items-center justify-center font-bold text-sm">
                        {engine}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-blue-50 border-l-4 border-blue-600 p-4 flex items-start space-x-3">
                  <AlertCircle size={20} className="text-blue-600 mt-0.5" />
                  <div className="text-xs text-blue-900">
                    <p className="font-bold">StreamX Free Tier</p>
                    <p>Qualifies for free monthly usage up to 750 hours on db.t3.micro instances.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-gray-50 px-6 py-4 border-t border-gray-200 flex justify-end space-x-3">
              <button onClick={() => setIsCreateModalOpen(false)} className="px-6 py-2 text-sm font-bold text-gray-700 border border-gray-300 bg-white rounded">Cancel</button>
              <button onClick={handleCreateDB} className="px-6 py-2 text-sm font-bold bg-[#ec7211] text-white rounded shadow hover:bg-[#d66100]">Create Database</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
