
import { GoogleGenAI } from "@google/genai";

/* Correct initialization: Must use a named parameter with process.env.API_KEY directly. */
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateAssistantResponse = async (history: string[], userMessage: string): Promise<string> => {
  try {
    /* Correct method: Use ai.models.generateContent to query GenAI with both the model and prompt. */
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userMessage,
      config: { 
        systemInstruction: "You are Cloud Q, an expert AI for StreamX Cloud Services. Help users manage EC2 and S3." 
      }
    });
    
    /* Correct Method: Access the .text property directly (not as a method call). */
    return response.text || "I am currently offline.";
  } catch (error) {
    console.error("Gemini AI error:", error);
    return "An error occurred with the AI service.";
  }
};
